<?php
session_start();

// jika belum login
if (!isset($_SESSION['login'])) {
    header("Location: ../auth/login.php");
    exit;
}

// fungsi cek role
function cekRole($role) {
    if ($_SESSION['role'] != $role) {
        header("Location: ../index.php");
        exit;
    }
}
