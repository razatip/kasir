<?php
require_once __DIR__ . "/../main/auth.php";
cekRole('admin');

require_once __DIR__ . "/../main/connect.php";
require_once "header.php";
require_once "sidebar_admin.php";

$barang = mysqli_query($conn, "SELECT * FROM barang");

if (isset($_POST['simpan'])) {
    $nama      = mysqli_real_escape_string($conn, $_POST['nama']);
    $barangID  = $_POST['barang'];
    $jumlah    = (int)$_POST['jumlah'];
    $uangBayar = (int)$_POST['uang_bayar'];

    if ($nama && $barangID && $jumlah > 0) {
        // 1. Ambil Harga Barang
        $getBarang = mysqli_query($conn, "SELECT Harga FROM barang WHERE BarangID='$barangID'");
        $b = mysqli_fetch_assoc($getBarang);
        $harga = $b['Harga'];

        $totalHarga = $harga * $jumlah;
        $kembalian  = $uangBayar - $totalHarga;

        if ($kembalian < 0) {
            echo "<script>alert('Uang bayar tidak cukup!'); window.history.back();</script>";
            exit;
        }

        // 2. Cek/Buat User (Optional jika UserID wajib di tabel penjualan)
        $cekUser = mysqli_query($conn, "SELECT UserID FROM user WHERE Username='$nama' LIMIT 1");
        if (mysqli_num_rows($cekUser) > 0) {
            $u = mysqli_fetch_assoc($cekUser);
            $userID = $u['UserID'];
        } else {
            $pass = password_hash("123456", PASSWORD_DEFAULT);
            mysqli_query($conn, "INSERT INTO user (Username, Password, Role) VALUES ('$nama', '$pass', 'customer')");
            $userID = mysqli_insert_id($conn);
        }

        // 3. Simpan Penjualan (Sesuai kolom database kamu)
        $queryPenjualan = "INSERT INTO penjualan (Tanggal, UserID, TotalHarga, NamaPelanggan, UangBayar, Kembalian) 
                           VALUES (NOW(), '$userID', '$totalHarga', '$nama', '$uangBayar', '$kembalian')";
        
        if (mysqli_query($conn, $queryPenjualan)) {
            $penjualanID = mysqli_insert_id($conn);
            
            // 4. Simpan Detail Penjualan
            mysqli_query($conn, "INSERT INTO detail_penjualan (PenjualanID, BarangID, Jumlah, Subtotal) 
                                 VALUES ('$penjualanID', '$barangID', '$jumlah', '$totalHarga')");

            echo "<script>alert('Transaksi Berhasil!'); window.location='pelanggan.php';</script>";
        } else {
            echo "Error: " . mysqli_error($conn);
        }
    }
}
?>

<div class="col-10 p-4">
    <h3>Tambah Transaksi Baru</h3>
    <a href="pelanggan.php" class="btn btn-secondary mb-3">← Kembali</a>

    <div class="card p-4 shadow-sm">
        <form method="post">
            <div class="mb-3">
                <label class="form-label">Nama Pelanggan</label>
                <input type="text" name="nama" class="form-control" placeholder="Masukkan nama pelanggan" required>
            </div>

            <div class="mb-3">
                <label class="form-label">Pilih Barang</label>
                <select name="barang" id="barang" class="form-control" required onchange="hitungTotal()">
                    <option value="" data-harga="0">-- Pilih Barang --</option>
                    <?php while($br = mysqli_fetch_assoc($barang)) { ?>
                        <option value="<?= $br['BarangID'] ?>" data-harga="<?= $br['Harga'] ?>">
                            <?= $br['NamaBarang'] ?> - Rp <?= number_format($br['Harga'],0,',','.') ?>
                        </option>
                    <?php } ?>
                </select>
            </div>

            <div class="row">
                <div class="col-md-6 mb-3">
                    <label class="form-label">Jumlah</label>
                    <input type="number" name="jumlah" id="jumlah" class="form-control" min="1" value="1" required oninput="hitungTotal()">
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label">Total Harus Dibayar</label>
                    <input type="text" id="total_display" class="form-control" readonly value="Rp 0">
                </div>
            </div>

            <div class="row">
                <div class="col-md-6 mb-3">
                    <label class="form-label">Uang Bayar</label>
                    <input type="number" name="uang_bayar" id="uang_bayar" class="form-control" required oninput="hitungTotal()">
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label">Kembalian</label>
                    <input type="text" id="kembalian_display" class="form-control" readonly value="Rp 0">
                </div>
            </div>

            <button type="submit" name="simpan" class="btn btn-success w-100 mt-3">Simpan Transaksi</button>
        </form>
    </div>
</div>

<script>
function hitungTotal() {
    const selectBarang = document.getElementById('barang');
    const harga = selectBarang.options[selectBarang.selectedIndex].getAttribute('data-harga');
    const jumlah = document.getElementById('jumlah').value;
    const uangBayar = document.getElementById('uang_bayar').value;

    const total = harga * jumlah;
    document.getElementById('total_display').value = "Rp " + total.toLocaleString('id-ID');

    const kembalian = uangBayar - total;
    if (kembalian >= 0) {
        document.getElementById('kembalian_display').value = "Rp " + kembalian.toLocaleString('id-ID');
    } else {
        document.getElementById('kembalian_display').value = "Uang Kurang";
    }
}
</script>