<?php
require_once __DIR__ . "/../main/auth.php";
cekRole('admin');
require_once __DIR__ . "/../main/connect.php";

$jenis = $_GET['jenis'] ?? 'pembelian';
$dari  = $_GET['dari'] ?? date('Y-m-01');
$sampai= $_GET['sampai'] ?? date('Y-m-d');

header("Content-Type: application/vnd.ms-excel");
header("Content-Disposition: attachment; filename=laporan_$jenis.xls");
?>

<table border="1">
<?php
// ================= PEMBELIAN =================
if ($jenis == 'pembelian') {
    echo "
    <tr>
        <th>No</th>
        <th>Tanggal</th>
        <th>No Pembelian</th>
        <th>Supplier</th>
        <th>Total Harga</th>
    </tr>";

    $q = mysqli_query($conn, "
        SELECT p.*, s.NamaSupplier
        FROM pembelian p
        JOIN supplier s ON p.SupplierID = s.SupplierID
        WHERE p.TanggalPembelian BETWEEN '$dari' AND '$sampai'
    ");

    $no = 1;
    while ($r = mysqli_fetch_assoc($q)) {
        echo "
        <tr>
            <td>$no</td>
            <td>{$r['TanggalPembelian']}</td>
            <td>{$r['PembelianID']}</td>
            <td>{$r['NamaSupplier']}</td>
            <td>{$r['TotalHarga']}</td>
        </tr>";
        $no++;
    }
}

// ================= STOK =================
if ($jenis == 'stok') {
    echo "
    <tr>
        <th>No</th>
        <th>Nama Barang</th>
        <th>Harga</th>
        <th>Stok</th>
    </tr>";

    $q = mysqli_query($conn, "SELECT * FROM barang");
    $no = 1;
    while ($r = mysqli_fetch_assoc($q)) {
        echo "
        <tr>
            <td>$no</td>
            <td>{$r['NamaBarang']}</td>
            <td>{$r['Harga']}</td>
            <td>{$r['Stok']}</td>
        </tr>";
        $no++;
    }
}
/* ================= SUPPLIER ================= */
if ($jenis == 'supplier') {
    echo "
    <tr>
        <th>No</th>
        <th>Nama Supplier</th>
        <th>Jumlah Transaksi</th>
        <th>Total Pembelian</th>
    </tr>";

    $q = mysqli_query($conn,"
        SELECT s.NamaSupplier,
               COUNT(p.PembelianID) jumlah,
               SUM(p.TotalHarga) total
        FROM supplier s
        LEFT JOIN pembelian p ON s.SupplierID=p.SupplierID
        AND p.TanggalPembelian BETWEEN '$dari' AND '$sampai'
        GROUP BY s.SupplierID
    ");

    $no=1;
    while($r=mysqli_fetch_assoc($q)){
        echo "
        <tr>
            <td>$no</td>
            <td>{$r['NamaSupplier']}</td>
            <td>{$r['jumlah']}</td>
            <td>{$r['total']}</td>
        </tr>";
        $no++;
    }
}

?>
</table>

