<?php
require_once __DIR__ . "/../main/auth.php";
cekRole('admin');
require_once __DIR__ . "/../main/connect.php";

$id = $_GET['id'];
mysqli_query($conn, "DELETE FROM supplier WHERE SupplierID='$id'");

header("Location: supplier.php");
exit;
