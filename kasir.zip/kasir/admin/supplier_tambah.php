<?php
require_once __DIR__ . "/../main/auth.php";
cekRole('admin');
require_once __DIR__ . "/../main/connect.php";

// --- PROSES FORM SEBELUM HTML ---
if (isset($_POST['simpan'])) {
    $nama   = mysqli_real_escape_string($conn, $_POST['nama']);
    $alamat = mysqli_real_escape_string($conn, $_POST['alamat']);
    $telp   = mysqli_real_escape_string($conn, $_POST['telp']);

    $query = "
        INSERT INTO supplier (NamaSupplier, Alamat, No_Telp)
        VALUES ('$nama', '$alamat', '$telp')
    ";

    if (mysqli_query($conn, $query)) {
        header("Location: supplier.php"); // redirect aman
        exit;
    } else {
        die("Error: " . mysqli_error($conn));
    }
}

// --- MULAI HTML ---
require_once "header.php";
require_once "sidebar_admin.php";
?>

<div class="col-10 p-4">
    <h4>Tambah Supplier</h4>

    <div class="card shadow-sm">
        <div class="card-body">
            <form method="POST">
                <div class="mb-3">
                    <label class="form-label">Nama Supplier</label>
                    <input type="text" name="nama" class="form-control" required>
                </div>

                <div class="mb-3">
                    <label class="form-label">Alamat</label>
                    <textarea name="alamat" class="form-control" required></textarea>
                </div>

                <div class="mb-3">
                    <label class="form-label">No Telp</label>
                    <input type="text" name="telp" class="form-control" required>
                </div>

                <button name="simpan" class="btn btn-primary">Simpan</button>
                <a href="supplier.php" class="btn btn-secondary">Kembali</a>
            </form>
        </div>
    </div>
</div>

<?php require_once "footer.php"; ?>
