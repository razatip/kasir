<?php
require_once __DIR__ . "/../main/auth.php";
cekRole('admin');
require_once __DIR__ . "/../main/connect.php";
require_once "header.php";
require_once "sidebar_admin.php";
require_once __DIR__ . "/../fpdf186/fpdf.php";


// Default: tampilkan semua laporan
$jenis_laporan = $_GET['jenis'] ?? 'pembelian';
$dari_tanggal = $_GET['dari'] ?? date('Y-m-01');
$sampai_tanggal = $_GET['sampai'] ?? date('Y-m-d');
?>

<div class="col-10 p-4">
    <h4>Laporan</h4>

    <div class="card shadow-sm mb-3">
        <div class="card-body">
            <form method="GET" class="row g-3">
                <div class="col-md-3">
                    <label class="form-label">Jenis Laporan</label>
                    <select name="jenis" class="form-select" onchange="this.form.submit()">
                        <option value="pembelian" <?= $jenis_laporan == 'pembelian' ? 'selected' : '' ?>>
                            Laporan Pembelian
                        </option>
                        <option value="stok" <?= $jenis_laporan == 'stok' ? 'selected' : '' ?>>
                            Laporan Stok Barang
                        </option>
                        <option value="supplier" <?= $jenis_laporan == 'supplier' ? 'selected' : '' ?>>
                            Laporan per Supplier
                        </option>
                        <option value="detail" <?= $jenis_laporan == 'detail' ? 'selected' : '' ?>>
                            Laporan Detail Pembelian
                        </option>
                    </select>
                </div>

                <?php if ($jenis_laporan != 'stok') : ?>
                <div class="col-md-3">
                    <label class="form-label">Dari Tanggal</label>
                    <input type="date" name="dari" class="form-control" value="<?= $dari_tanggal ?>">
                </div>

                <div class="col-md-3">
                    <label class="form-label">Sampai Tanggal</label>
                    <input type="date" name="sampai" class="form-control" value="<?= $sampai_tanggal ?>">
                </div>

                <div class="col-md-3">
                    <label class="form-label">&nbsp;</label>
                    <button type="submit" class="btn btn-primary w-100">Tampilkan</button>
                </div>
                <?php endif; ?>
            </form>
        </div>
    </div>

    <?php
    // ============ LAPORAN PEMBELIAN ============
    if ($jenis_laporan == 'pembelian') :
        $query = mysqli_query($conn, "
            SELECT p.*, s.NamaSupplier 
            FROM pembelian p
            JOIN supplier s ON p.SupplierID = s.SupplierID
            WHERE p.TanggalPembelian BETWEEN '$dari_tanggal' AND '$sampai_tanggal'
            ORDER BY p.TanggalPembelian DESC
        ");
        
        $total_pembelian = 0;
    ?>
    
    <div class="card shadow-sm">
        <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
            <h5 class="mb-0">Laporan Pembelian (<?= date('d/m/Y', strtotime($dari_tanggal)) ?> - <?= date('d/m/Y', strtotime($sampai_tanggal)) ?>)</h5>
            <div>
                <button onclick="window.print()" class="btn btn-light btn-sm">
                    Print
                </button>
                <a href="laporan_export_pdf.php?jenis=pembelian&dari=<?= $dari_tanggal ?>&sampai=<?= $sampai_tanggal ?>" 
                   class="btn btn-danger btn-sm" target="_blank">
                    Export PDF
                </a>
                <a href="laporan_export_excel.php?jenis=pembelian&dari=<?= $dari_tanggal ?>&sampai=<?= $sampai_tanggal ?>" 
                   class="btn btn-success btn-sm">
                    Export Excel
                </a>
            </div>
        </div>
        <div class="card-body">
            <table class="table table-bordered table-striped">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Tanggal</th>
                        <th>No Pembelian</th>
                        <th>Supplier</th>
                        <th>Total Harga</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    $no = 1;
                    while ($row = mysqli_fetch_assoc($query)) : 
                        $total_pembelian += $row['TotalHarga'];
                    ?>
                    <tr>
                        <td><?= $no++ ?></td>
                        <td><?= date('d/m/Y', strtotime($row['TanggalPembelian'])) ?></td>
                        <td><?= $row['pembelianID'] ?></td>
                        <td><?= $row['NamaSupplier'] ?></td>
                        <td>Rp <?= number_format($row['TotalHarga'], 0, ',', '.') ?></td>
                    </tr>
                    <?php endwhile; ?>
                    
                    <tr>
                        <td colspan="4" class="text-end"><strong>TOTAL PEMBELIAN</strong></td>
                        <td><strong>Rp <?= number_format($total_pembelian, 0, ',', '.') ?></strong></td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>

    <?php
    // ============ LAPORAN STOK BARANG ============
    elseif ($jenis_laporan == 'stok') :
        $query = mysqli_query($conn, "
            SELECT * FROM barang ORDER BY NamaBarang
        ");
    ?>
    
    <div class="card shadow-sm">
        <div class="card-header bg-success text-white d-flex justify-content-between align-items-center">
            <h5 class="mb-0">Laporan Stok Barang (Per <?= date('d/m/Y') ?>)</h5>
            <div>
                <button onclick="window.print()" class="btn btn-light btn-sm">
                    Print
                </button>
                <a href="laporan_export_pdf.php?jenis=stok" class="btn btn-danger btn-sm" target="_blank">
                    Export PDF
                </a>
                <a href="laporan_export_excel.php?jenis=stok" class="btn btn-success btn-sm">
                    Export Excel
                </a>
            </div>
        </div>
        <div class="card-body">
            <table class="table table-bordered table-striped">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Nama Barang</th>
                        <th>Harga</th>
                        <th>Stok</th>
                        <th>Total Nilai</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    $no = 1;
                    $total_nilai = 0;
                    while ($row = mysqli_fetch_assoc($query)) : 
                        $nilai = $row['Harga'] * $row['Stok'];
                        $total_nilai += $nilai;
                        
                        $status = '';
                        $badge = '';
                        if ($row['Stok'] == 0) {
                            $status = 'Habis';
                            $badge = 'bg-danger';
                        } elseif ($row['Stok'] <= 5) {
                            $status = 'Stok Menipis';
                            $badge = 'bg-warning';
                        } else {
                            $status = 'Aman';
                            $badge = 'bg-success';
                        }
                    ?>
                    <tr>
                        <td><?= $no++ ?></td>
                        <td><?= $row['NamaBarang'] ?></td>
                        <td>Rp <?= number_format($row['Harga'], 0, ',', '.') ?></td>
                        <td><?= $row['Stok'] ?></td>
                        <td>Rp <?= number_format($nilai, 0, ',', '.') ?></td>
                        <td><span class="badge <?= $badge ?>"><?= $status ?></span></td>
                    </tr>
                    <?php endwhile; ?>
                    
                    <tr>
                        <td colspan="4" class="text-end"><strong>TOTAL NILAI STOK</strong></td>
                        <td colspan="2"><strong>Rp <?= number_format($total_nilai, 0, ',', '.') ?></strong></td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>

    <?php
    // ============ LAPORAN PER SUPPLIER ============
    elseif ($jenis_laporan == 'supplier') :
        $query = mysqli_query($conn, "
            SELECT s.SupplierID, s.NamaSupplier, 
                   COUNT(p.pembelianID) as JumlahTransaksi,
                   SUM(p.TotalHarga) as TotalPembelian
            FROM supplier s
            LEFT JOIN pembelian p ON s.SupplierID = p.SupplierID
                AND p.TanggalPembelian BETWEEN '$dari_tanggal' AND '$sampai_tanggal'
            GROUP BY s.SupplierID
            ORDER BY TotalPembelian DESC
        ");
        
        $grand_total = 0;
    ?>
    
    <div class="card shadow-sm">
        <div class="card-header bg-warning d-flex justify-content-between align-items-center">
            <h5 class="mb-0">Laporan Pembelian per Supplier (<?= date('d/m/Y', strtotime($dari_tanggal)) ?> - <?= date('d/m/Y', strtotime($sampai_tanggal)) ?>)</h5>
            <div>
                <button onclick="window.print()" class="btn btn-light btn-sm">
                    Print
                </button>
                <a href="laporan_export_pdf.php?jenis=supplier&dari=<?= $dari_tanggal ?>&sampai=<?= $sampai_tanggal ?>" 
                   class="btn btn-danger btn-sm" target="_blank">
                    Export PDF
                </a>
                <a href="laporan_export_excel.php?jenis=supplier&dari=<?= $dari_tanggal ?>&sampai=<?= $sampai_tanggal ?>" 
                   class="btn btn-success btn-sm">
                    Export Excel
                </a>
            </div>
        </div>
        <div class="card-body">
            <table class="table table-bordered table-striped">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Nama Supplier</th>
                        <th>Jumlah Transaksi</th>
                        <th>Total Pembelian</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    $no = 1;
                    while ($row = mysqli_fetch_assoc($query)) : 
                        $grand_total += $row['TotalPembelian'];
                    ?>
                    <tr>
                        <td><?= $no++ ?></td>
                        <td><?= $row['NamaSupplier'] ?></td>
                        <td><?= $row['JumlahTransaksi'] ?></td>
                        <td>Rp <?= number_format($row['TotalPembelian'], 0, ',', '.') ?></td>
                    </tr>
                    <?php endwhile; ?>
                    
                    <tr>
                        <td colspan="3" class="text-end"><strong>GRAND TOTAL</strong></td>
                        <td><strong>Rp <?= number_format($grand_total, 0, ',', '.') ?></strong></td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>

    <?php
    // ============ LAPORAN DETAIL PEMBELIAN ============
    elseif ($jenis_laporan == 'detail') :
        $query = mysqli_query($conn, "
            SELECT p.pembelianID, p.TanggalPembelian, s.NamaSupplier,
                   dp.Jumlah, dp.Subtotal, b.NamaBarang, b.Harga
            FROM pembelian p
            JOIN supplier s ON p.SupplierID = s.SupplierID
            JOIN detail_pembelian dp ON p.pembelianID = dp.pembelianID
            JOIN barang b ON dp.BarangID = b.BarangID
            WHERE p.TanggalPembelian BETWEEN '$dari_tanggal' AND '$sampai_tanggal'
            ORDER BY p.TanggalPembelian DESC, p.pembelianID
        ");
        
        $grand_total = 0;
    ?>
    
    <div class="card shadow-sm">
        <div class="card-header bg-info text-white d-flex justify-content-between align-items-center">
            <h5 class="mb-0">Laporan Detail Pembelian (<?= date('d/m/Y', strtotime($dari_tanggal)) ?> - <?= date('d/m/Y', strtotime($sampai_tanggal)) ?>)</h5>
            <div>
                <button onclick="window.print()" class="btn btn-light btn-sm">
                    Print
                </button>
                <a href="laporan_export_pdf.php?jenis=detail&dari=<?= $dari_tanggal ?>&sampai=<?= $sampai_tanggal ?>" 
                   class="btn btn-danger btn-sm" target="_blank">
                    Export PDF
                </a>
                <a href="laporan_export_excel.php?jenis=detail&dari=<?= $dari_tanggal ?>&sampai=<?= $sampai_tanggal ?>" 
                   class="btn btn-success btn-sm">
                    Export Excel
                </a>
            </div>
        </div>
        <div class="card-body">
            <table class="table table-bordered table-striped">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Tanggal</th>
                        <th>No Pembelian</th>
                        <th>Supplier</th>
                        <th>Nama Barang</th>
                        <th>Harga Satuan</th>
                        <th>Jumlah</th>
                        <th>Subtotal</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    $no = 1;
                    while ($row = mysqli_fetch_assoc($query)) : 
                        $grand_total += $row['Subtotal'];
                    ?>
                    <tr>
                        <td><?= $no++ ?></td>
                        <td><?= date('d/m/Y', strtotime($row['TanggalPembelian'])) ?></td>
                        <td><?= $row['pembelianID'] ?></td>
                        <td><?= $row['NamaSupplier'] ?></td>
                        <td><?= $row['NamaBarang'] ?></td>
                        <td>Rp <?= number_format($row['Harga'], 0, ',', '.') ?></td>
                        <td><?= $row['Jumlah'] ?></td>
                        <td>Rp <?= number_format($row['Subtotal'], 0, ',', '.') ?></td>
                    </tr>
                    <?php endwhile; ?>
                    
                    <tr>
                        <td colspan="7" class="text-end"><strong>GRAND TOTAL</strong></td>
                        <td><strong>Rp <?= number_format($grand_total, 0, ',', '.') ?></strong></td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>

    <?php endif; ?>
</div>

<style>
@media print {
    .btn, nav, .col-2, .card-header div, form { display: none !important; }
    .col-10 { width: 100% !important; max-width: 100% !important; }
    .card { border: none !important; }
}
</style>

<?php require_once "footer.php"; ?>