<?php
require_once __DIR__ . "/../main/auth.php";
cekRole('admin');
require_once __DIR__ . "/../main/connect.php";

// ===== LOGIKA PROSES =====
if (isset($_POST['simpan'])) {

    $nama  = mysqli_real_escape_string($conn, $_POST['nama']);
    $harga = (int) $_POST['harga'];
    $stok  = (int) $_POST['stok'];

    $fotoName = $_FILES['foto']['name'];
    $tmpName  = $_FILES['foto']['tmp_name'];

    $folder = __DIR__ . "../assets/img";
    $path   = $folder . $fotoName;

    move_uploaded_file($tmpName, $path);

    mysqli_query($conn, "
        INSERT INTO barang (NamaBarang, Harga, Stok, foto)
        VALUES ('$nama', '$harga', '$stok', '$fotoName')
    ");

    header("Location: barang.php");
    exit;
}

require_once "header.php";
require_once "sidebar_admin.php";
?>
<div class="col-10 p-4">
    <h4>Tambah Barang</h4>

    <div class="card shadow-sm">
        <div class="card-body">

            <form method="POST" enctype="multipart/form-data">

                <div class="row mb-3">
                    <div class="col-md-6">
                        <label class="form-label">Nama Barang</label>
                        <input type="text" name="nama" class="form-control"
                               placeholder="Masukkan nama barang" required>
                    </div>

                    <div class="col-md-3">
                        <label class="form-label">Harga</label>
                        <input type="number" name="harga" class="form-control"
                               placeholder="Contoh: 150000" required>
                    </div>

                    <div class="col-md-3">
                        <label class="form-label">Stok</label>
                        <input type="number" name="stok" class="form-control"
                               placeholder="Jumlah stok" required>
                    </div>
                </div>

                <div class="mb-3">
                    <label class="form-label">Foto Barang</label>
                    <input type="file" name="foto" class="form-control" required>
                </div>

                <div class="mt-3">
                    <button name="simpan" class="btn btn-primary">
                        Simpan Barang
                    </button>
                    <a href="barang.php" class="btn btn-secondary">
                        Kembali
                    </a>
                </div>

            </form>

        </div>
    </div>
</div>
