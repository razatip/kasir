<?php
require_once __DIR__ . "/../main/auth.php";
cekRole('admin');
require_once __DIR__ . "/../main/connect.php";
require_once __DIR__ . "/../fpdf186/fpdf.php";

$jenis  = $_GET['jenis'] ?? 'pembelian';
$dari   = $_GET['dari'] ?? date('Y-m-01');
$sampai = $_GET['sampai'] ?? date('Y-m-d');

$pdf = new FPDF('P','mm','A4');
$pdf->AddPage();
$pdf->SetFont('Arial','B',14);
$pdf->Cell(0,10,'LAPORAN',0,1,'C');
$pdf->Ln(5);
$pdf->SetFont('Arial','',10);

/* ================= PEMBELIAN ================= */
if ($jenis == 'pembelian') {

    $pdf->Cell(0,8,"Laporan Pembelian ($dari s/d $sampai)",0,1);

    $pdf->SetFont('Arial','B',10);
    $pdf->Cell(10,8,'No',1);
    $pdf->Cell(30,8,'Tanggal',1);
    $pdf->Cell(35,8,'ID',1);
    $pdf->Cell(60,8,'Supplier',1);
    $pdf->Cell(40,8,'Total',1);
    $pdf->Ln();

    $pdf->SetFont('Arial','',10);
    $q = mysqli_query($conn,"
        SELECT p.*, s.NamaSupplier 
        FROM pembelian p
        JOIN supplier s ON p.SupplierID=s.SupplierID
        WHERE p.TanggalPembelian BETWEEN '$dari' AND '$sampai'
    ");

    $no=1; $total=0;
    while($r=mysqli_fetch_assoc($q)){
        $pdf->Cell(10,8,$no++,1);
        $pdf->Cell(30,8,$r['TanggalPembelian'],1);
        $pdf->Cell(35,8,$r['pembelianID'],1);
        $pdf->Cell(60,8,$r['NamaSupplier'],1);
        $pdf->Cell(40,8,'Rp '.number_format($r['TotalHarga'],0,',','.'),1);
        $pdf->Ln();
        $total += $r['TotalHarga'];
    }

    $pdf->SetFont('Arial','B',10);
    $pdf->Cell(135,8,'TOTAL',1);
    $pdf->Cell(40,8,'Rp '.number_format($total,0,',','.'),1);
}

/* ================= STOK ================= */
elseif ($jenis == 'stok') {

    $pdf->Cell(0,8,"Laporan Stok Barang",0,1);

    $pdf->SetFont('Arial','B',10);
    $pdf->Cell(10,8,'No',1);
    $pdf->Cell(70,8,'Barang',1);
    $pdf->Cell(30,8,'Harga',1);
    $pdf->Cell(20,8,'Stok',1);
    $pdf->Cell(40,8,'Total',1);
    $pdf->Ln();

    $pdf->SetFont('Arial','',10);
    $q = mysqli_query($conn,"SELECT * FROM barang");

    $no=1;
    while($r=mysqli_fetch_assoc($q)){
        $pdf->Cell(10,8,$no++,1);
        $pdf->Cell(70,8,$r['NamaBarang'],1);
        $pdf->Cell(30,8,'Rp '.number_format($r['Harga'],0,',','.'),1);
        $pdf->Cell(20,8,$r['Stok'],1);
        $pdf->Cell(40,8,'Rp '.number_format($r['Harga']*$r['Stok'],0,',','.'),1);
        $pdf->Ln();
    }
}

/* ================= SUPPLIER ================= */
elseif ($jenis == 'supplier') {

    $pdf->Cell(0,8,"Laporan Pembelian per Supplier",0,1);

    $pdf->SetFont('Arial','B',10);
    $pdf->Cell(10,8,'No',1);
    $pdf->Cell(80,8,'Supplier',1);
    $pdf->Cell(40,8,'Transaksi',1);
    $pdf->Cell(50,8,'Total',1);
    $pdf->Ln();

    $pdf->SetFont('Arial','',10);
    $q = mysqli_query($conn,"
        SELECT s.NamaSupplier,
               COUNT(p.pembelianID) jumlah,
               SUM(p.TotalHarga) total
        FROM supplier s
        LEFT JOIN pembelian p ON s.SupplierID=p.SupplierID
        AND p.TanggalPembelian BETWEEN '$dari' AND '$sampai'
        GROUP BY s.SupplierID
    ");

    $no=1;
    while($r=mysqli_fetch_assoc($q)){
        $pdf->Cell(10,8,$no++,1);
        $pdf->Cell(80,8,$r['NamaSupplier'],1);
        $pdf->Cell(40,8,$r['jumlah'],1);
        $pdf->Cell(50,8,'Rp '.number_format($r['total'],0,',','.'),1);
        $pdf->Ln();
    }
}

$pdf->Output('I','laporan.pdf');
