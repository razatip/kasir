<?php
require_once __DIR__ . "/../main/auth.php";
cekRole('admin');
require_once __DIR__ . "/../main/connect.php";

// Ambil ID supplier dari GET
$id = $_GET['id'] ?? '';
if (!$id) {
    die("ID supplier tidak ditemukan!");
}

// --- PROSES UPDATE SEBELUM HTML ---
if (isset($_POST['update'])) {
    $nama   = mysqli_real_escape_string($conn, $_POST['nama']);
    $alamat = mysqli_real_escape_string($conn, $_POST['alamat']);
    $telp   = mysqli_real_escape_string($conn, $_POST['telp']);

    $query = "
        UPDATE supplier SET
        NamaSupplier='$nama',
        Alamat='$alamat',
        No_Telp='$telp'
        WHERE SupplierID='$id'
    ";

    if (mysqli_query($conn, $query)) {
        header("Location: supplier.php");
        exit;
    } else {
        die("Error updating record: " . mysqli_error($conn));
    }
}

// --- AMBIL DATA SUPPLIER UNTUK FORM ---
$result = mysqli_query($conn, "SELECT * FROM supplier WHERE SupplierID='$id'");
if (!$result || mysqli_num_rows($result) == 0) {
    die("Supplier tidak ditemukan!");
}
$data = mysqli_fetch_assoc($result);

// --- MULAI HTML ---
require_once "header.php";
require_once "sidebar_admin.php";
?>

<div class="col-10 p-4">
    <h4>Edit Supplier</h4>

    <div class="card shadow-sm">
        <div class="card-body">
            <form method="POST">
                <div class="mb-3">
                    <label class="form-label">Nama Supplier</label>
                    <input type="text" name="nama" class="form-control"
                           value="<?= htmlspecialchars($data['NamaSupplier']) ?>" required>
                </div>

                <div class="mb-3">
                    <label class="form-label">Alamat</label>
                    <textarea name="alamat" class="form-control" required><?= htmlspecialchars($data['Alamat']) ?></textarea>
                </div>

                <div class="mb-3">
                    <label class="form-label">No Telp</label>
                    <input type="text" name="telp" class="form-control"
                           value="<?= htmlspecialchars($data['No_Telp']) ?>" required>
                </div>

                <button name="update" class="btn btn-warning">Update</button>
                <a href="supplier.php" class="btn btn-secondary">Kembali</a>
            </form>
        </div>
    </div>
</div>

<?php require_once "footer.php"; ?>
