<?php
require_once __DIR__ . "/../main/auth.php";
cekRole('admin');
require_once __DIR__ . "/../main/connect.php";
require_once "header.php";
require_once "sidebar_admin.php";

$data = mysqli_query($conn, "SELECT * FROM barang");
?>

<div class="col-10 p-4">
    <h4>Data Barang</h4>

    <a href="barang_tambah.php" class="btn btn-primary mb-3">
        + Tambah Barang
    </a>

    <table class="table table-bordered table-striped">
        <tr>
            <th>No</th>
            <th>Foto</th>
            <th>Nama Barang</th>
            <th>Harga</th>
            <th>Stok</th>
            <th>Aksi</th>
        </tr>

        <?php $no = 1; while ($row = mysqli_fetch_assoc($data)) : ?>
        <tr>
            <td><?= $no++ ?></td>

            <td>
                <img src="../assets/img/<?= $row['foto'] ?>"
                     width="60" height="60"
                     style="object-fit:cover;">
            </td>

            <td><?= $row['NamaBarang'] ?></td>

            <td>
                Rp <?= number_format($row['Harga'], 0, ',', '.') ?>
            </td>

            <td><?= $row['stok'] ?></td>

            <td>
                <a href="barang_edit.php?id=<?= $row['BarangID'] ?>"
                   class="btn btn-warning btn-sm">Edit</a>

                <a href="barang_hapus.php?id=<?= $row['BarangID'] ?>"
                   class="btn btn-danger btn-sm"
                   onclick="return confirm('Yakin hapus barang?')">
                   Hapus
                </a>
            </td>
        </tr>
        <?php endwhile; ?>
    </table>
</div>

<?php require_once "footer.php"; ?>
