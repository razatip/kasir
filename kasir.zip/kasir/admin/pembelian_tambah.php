<?php
require_once __DIR__ . "/../main/auth.php";
cekRole('admin');
require_once __DIR__ . "/../main/connect.php";
$idUser = $_SESSION['id_user'];

// --- Ambil data supplier dan barang ---
$suppliers = mysqli_query($conn, "SELECT * FROM supplier ORDER BY NamaSupplier");
$barang_list = mysqli_query($conn, "SELECT * FROM barang ORDER BY NamaBarang");

// --- PROSES SIMPAN PEMBELIAN SEBELUM HTML ---
if (isset($_POST['simpan'])) {
    $tanggal = mysqli_real_escape_string($conn, $_POST['tanggal']);
    $supplier_id = (int) $_POST['supplier_id'];
    $barang_ids = $_POST['barang_id'];
    $jumlahs = $_POST['jumlah'];

    $total = 0;

    // Hitung total pembelian
    foreach ($barang_ids as $key => $barang_id) {
        $barang_id = (int) $barang_id;
        $jumlah = (int) $jumlahs[$key];

        $harga_query = mysqli_query($conn, "SELECT Harga FROM barang WHERE BarangID='$barang_id'");
        $harga_data = mysqli_fetch_assoc($harga_query);
        $harga = (int) $harga_data['Harga'];

        $subtotal = $jumlah * $harga;
        $total += $subtotal;
    }

    // Insert ke tabel pembelian
    mysqli_query($conn, "INSERT INTO pembelian (TanggalPembelian, SupplierID, TotalHarga, UserID) VALUES ('$tanggal', '$supplier_id', '$total', '$idUser')");

    $pembelian_id = mysqli_insert_id($conn);

    // Insert detail pembelian & update stok
    foreach ($barang_ids as $key => $barang_id) {
        $barang_id = (int) $barang_id;
        $jumlah = (int) $jumlahs[$key];

        $harga_query = mysqli_query($conn, "SELECT Harga FROM barang WHERE BarangID='$barang_id'");
        $harga_data = mysqli_fetch_assoc($harga_query);
        $harga = (int) $harga_data['Harga'];

        $subtotal = $jumlah * $harga;

        mysqli_query($conn, "
            INSERT INTO detail_pembelian (PembelianID, BarangID, Jumlah, Subtotal)
            VALUES ('$pembelian_id', '$barang_id', '$jumlah', '$subtotal')
        ");

        mysqli_query($conn, "
            UPDATE barang SET stok = Stok + $jumlah WHERE BarangID = '$barang_id'
        ");
    }

    header("Location: pembelian.php"); // redirect aman
    exit;
}

// --- MULAI HTML ---
require_once "header.php";
require_once "sidebar_admin.php";
?>

<div class="col-10 p-4">
    <h4>Tambah Pembelian</h4>

    <div class="card shadow-sm">
        <div class="card-body">
            <form method="POST" id="formPembelian">
                <div class="row mb-3">
                    <div class="col-md-6">
                        <label class="form-label">Tanggal Pembelian</label>
                        <input type="date" name="tanggal" class="form-control" 
                               value="<?= date('Y-m-d') ?>" required>
                    </div>
                    
                    <div class="col-md-6">
                        <label class="form-label">Supplier</label>
                        <select name="supplier_id" class="form-select" required>
                            <option value="">-- Pilih Supplier --</option>
                            <?php 
                            mysqli_data_seek($suppliers, 0);
                            while ($sup = mysqli_fetch_assoc($suppliers)) : ?>
                                <option value="<?= $sup['SupplierID'] ?>">
                                    <?= htmlspecialchars($sup['NamaSupplier']) ?>
                                </option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                </div>

                <hr>
                <h5>Detail Barang</h5>
                
                <div id="itemContainer">
                    <div class="row mb-2 item-row">
                        <div class="col-md-6">
                            <label class="form-label">Barang</label>
                            <select name="barang_id[]" class="form-select barang-select" required>
                                <option value="">-- Pilih Barang --</option>
                                <?php 
                                mysqli_data_seek($barang_list, 0);
                                while ($brg = mysqli_fetch_assoc($barang_list)) : 
                                ?>
                                    <option value="<?= $brg['BarangID'] ?>" 
                                            data-harga="<?= $brg['Harga'] ?>"
                                            data-stok="<?= $brg['stok'] ?>">
                                        <?= htmlspecialchars($brg['NamaBarang']) ?> 
                                        (stok: <?= $brg['stok'] ?>, 
                                         Harga: Rp <?= number_format($brg['Harga'], 0, ',', '.') ?>)
                                    </option>
                                <?php endwhile; ?>
                            </select>
                        </div>
                        
                        <div class="col-md-3">
                            <label class="form-label">Jumlah</label>
                            <input type="number" name="jumlah[]" class="form-control jumlah-input" 
                                   min="1" value="1" required>
                        </div>
                        
                        <div class="col-md-2">
                            <label class="form-label">Subtotal</label>
                            <input type="text" class="form-control subtotal-display" readonly>
                        </div>
                        
                        <div class="col-md-1">
                            <label class="form-label">&nbsp;</label>
                            <button type="button" class="btn btn-danger btn-sm w-100 btn-remove" 
                                    onclick="removeItem(this)">X</button>
                        </div>
                    </div>
                </div>

                <button type="button" class="btn btn-success btn-sm mb-3" onclick="addItem()">
                    + Tambah Barang
                </button>

                <hr>
                
                <div class="row">
                    <div class="col-md-8 text-end">
                        <h5>Total Pembelian:</h5>
                    </div>
                    <div class="col-md-4">
                        <h5 id="totalDisplay">Rp 0</h5>
                        <input type="hidden" id="totalHarga" name="total_harga" value="0">
                    </div>
                </div>

                <div class="mt-3">
                    <button type="submit" name="simpan" class="btn btn-primary">
                        Simpan Pembelian
                    </button>
                    <a href="pembelian.php" class="btn btn-secondary">Kembali</a>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
// Data barang untuk JS
const barangData = [
    <?php 
    mysqli_data_seek($barang_list, 0);
    $items = [];
    while ($brg = mysqli_fetch_assoc($barang_list)) {
        $items[] = sprintf(
            '{id: %d, nama: "%s", harga: %d, stok: %d}',
            $brg['BarangID'],
            addslashes($brg['NamaBarang']),
            $brg['Harga'],
            $brg['stok']
        );
    }
    echo implode(",\n    ", $items);
    ?>
];

function addItem() {
    const container = document.getElementById('itemContainer');
    const newRow = container.querySelector('.item-row').cloneNode(true);
    newRow.querySelector('.barang-select').value = '';
    newRow.querySelector('.jumlah-input').value = 1;
    newRow.querySelector('.subtotal-display').value = '';
    container.appendChild(newRow);
    attachEventListeners();
}

function removeItem(btn) {
    const container = document.getElementById('itemContainer');
    if (container.querySelectorAll('.item-row').length > 1) {
        btn.closest('.item-row').remove();
        calculateTotal();
    } else {
        alert('Minimal harus ada 1 barang!');
    }
}

function attachEventListeners() {
    document.querySelectorAll('.barang-select, .jumlah-input').forEach(el => {
        el.removeEventListener('change', calculateSubtotal);
        el.removeEventListener('input', calculateSubtotal);
        el.addEventListener('change', calculateSubtotal);
        el.addEventListener('input', calculateSubtotal);
    });
}

function calculateSubtotal(e) {
    const row = e.target.closest('.item-row');
    const barangSelect = row.querySelector('.barang-select');
    const jumlahInput = row.querySelector('.jumlah-input');
    const subtotalDisplay = row.querySelector('.subtotal-display');
    
    const barangId = barangSelect.value;
    const jumlah = parseInt(jumlahInput.value) || 0;
    
    if (barangId && jumlah > 0) {
        const barang = barangData.find(b => b.id == barangId);
        if (barang) {
            const subtotal = barang.harga * jumlah;
            subtotalDisplay.value = 'Rp ' + subtotal.toLocaleString('id-ID');
        }
    } else {
        subtotalDisplay.value = '';
    }
    
    calculateTotal();
}

function calculateTotal() {
    let total = 0;
    
    document.querySelectorAll('.item-row').forEach(row => {
        const barangSelect = row.querySelector('.barang-select');
        const jumlahInput = row.querySelector('.jumlah-input');
        
        const barangId = barangSelect.value;
        const jumlah = parseInt(jumlahInput.value) || 0;
        
        if (barangId && jumlah > 0) {
            const barang = barangData.find(b => b.id == barangId);
            if (barang) {
                total += barang.harga * jumlah;
            }
        }
    });
    
    document.getElementById('totalDisplay').textContent = 'Rp ' + total.toLocaleString('id-ID');
    document.getElementById('totalHarga').value = total;
}

// Initialize
attachEventListeners();
calculateTotal();
</script>

<?php require_once "footer.php"; ?>
