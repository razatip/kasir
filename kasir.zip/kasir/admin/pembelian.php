<?php
require_once __DIR__ . "/../main/auth.php";
cekRole('admin');
require_once __DIR__ . "/../main/connect.php";
require_once "header.php";
require_once "sidebar_admin.php";

$data = mysqli_query($conn, "
    SELECT p.*, s.NamaSupplier 
    FROM pembelian p
    JOIN supplier s ON p.SupplierID = s.SupplierID
    ORDER BY p.TanggalPembelian DESC
");
?>

<div class="col-10 p-4">
    <h4>Data Pembelian</h4>

    <a href="pembelian_tambah.php" class="btn btn-primary mb-3">
        + Tambah Pembelian
    </a>

    <table class="table table-bordered table-striped">
        <thead>
            <tr>
                <th>No</th>
                <th>Tanggal</th>
                <th>Supplier</th>
                <th>Total Harga</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $no = 1; while ($row = mysqli_fetch_assoc($data)) : ?>
            <tr>
                <td><?= $no++ ?></td>
                <td><?= date('d/m/Y', strtotime($row['TanggalPembelian'])) ?></td>
                <td><?= $row['NamaSupplier'] ?></td>
                <td>Rp <?= number_format($row['TotalHarga'], 0, ',', '.') ?></td>
                <td>
                    <a href="pembelian_detail.php?id=<?= $row['pembelianID'] ?>"
                       class="btn btn-info btn-sm">Detail</a>
                    
                    <a href="pembelian_hapus.php?id=<?= $row['pembelianID'] ?>"
                       class="btn btn-danger btn-sm"
                       onclick="return confirm('Yakin hapus pembelian ini? Stok barang akan dikurangi kembali!')">
                       Hapus
                    </a>
                </td>
            </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</div>

<?php require_once "footer.php"; ?>