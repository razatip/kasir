<!DOCTYPE html>
<html lang="id">
    
<head>
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">

    <meta charset="UTF-8">
    <title>Shopee App</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">

    <style>
       /* ===== HEADER GLASS CLEAN ===== */
.admin-header {
    height: 64px;
    background: rgba(15, 23, 42, 0.85);
    backdrop-filter: blur(12px);
    -webkit-backdrop-filter: blur(12px);
    color: #e5e7eb;
    border-bottom: 1px solid rgba(255,255,255,0.06);
    position: sticky;
    top: 0;
    z-index: 50;
}

/* Brand */
.brand-box {
    display: flex;
    flex-direction: column;
}

.brand-title {
    font-size: 16px;
    font-weight: 600;
    letter-spacing: 0.4px;
}

.brand-subtitle {
    font-size: 11px;
    color: #94a3b8;
}

/* Actions */
.header-actions {
    display: flex;
    align-items: center;
    gap: 12px;
}

.admin-role {
    font-size: 12px;
    color: #c7d2fe;
    background: rgba(99,102,241,0.15);
    padding: 6px 12px;
    border-radius: 8px;
    border: 1px solid rgba(99,102,241,0.35);
    display: flex;
    align-items: center;
    gap: 6px;
}

/* Logout button icon only */
.btn-logout {
    width: 38px;
    height: 38px;
    display: grid;
    place-items: center;
    border-radius: 10px;
    background: rgba(255,255,255,0.06);
    color: #e5e7eb;
    border: 1px solid rgba(255,255,255,0.12);
    transition: all 0.2s ease;
}

.btn-logout:hover {
    background: rgba(239,68,68,0.15);
    border-color: #ef4444;
    color: #ef4444;
}

    </style>
    <style>
body {
    font-family: 'Poppins', system-ui, -apple-system, BlinkMacSystemFont, sans-serif;
    background-color: #f8fafc;
}
</style>

</head>



<body>
    <!-- MODAL LOGOUT -->
<div class="modal fade" id="logoutModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content border-0 shadow-lg rounded-4">

      <div class="modal-body text-center p-4">
        <div class="mb-3">
          <i class="bi bi-exclamation-triangle-fill text-danger" style="font-size:3rem;"></i>
        </div>

        <h5 class="fw-bold mb-2">Konfirmasi Logout</h5>
        <p class="text-muted mb-4">
          Apakah kamu yakin ingin keluar dari sistem?
        </p>

        <div class="d-flex justify-content-center gap-3">
          <button type="button" class="btn btn-secondary px-4" data-bs-dismiss="modal">
            Batal
          </button>
          <a href="#" id="confirmLogout" class="btn btn-danger px-4">
            Ya, Logout
          </a>
        </div>
      </div>

    </div>
  </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

<script>
document.addEventListener('DOMContentLoaded', function () {
    const logoutBtns = document.querySelectorAll('.logout-btn');
    const logoutModal = new bootstrap.Modal(document.getElementById('logoutModal'));
    const confirmLogout = document.getElementById('confirmLogout');

    logoutBtns.forEach(btn => {
        btn.addEventListener('click', function (e) {
            e.preventDefault();
            confirmLogout.href = this.href; // ambil link logout
            logoutModal.show();
        });
    });
});
</script>


<!-- HEADER -->
<nav class="admin-header d-flex align-items-center px-4">
    <div class="brand-box flex-grow-1">
        <span class="brand-title">Inventory Admin</span>
        <span class="brand-subtitle">Dashboard Management</span>
    </div>

    <div class="header-actions">
        <span class="admin-role">
            <i class="bi bi-shield-lock"></i>
            Administrator
        </span>

        <a href="../auth/logout.php" class="btn-logout logout-btn">
            <i class="bi bi-box-arrow-right"></i>
        </a>
    </div>
</nav>


<div class="container-fluid">
    <div class="row min-vh-100">
