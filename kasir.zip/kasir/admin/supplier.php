<?php
require_once __DIR__ . "/../main/auth.php";
cekRole('admin');
require_once __DIR__ . "/../main/connect.php";
require_once "header.php";
require_once "sidebar_admin.php";

$data = mysqli_query($conn, "SELECT * FROM supplier");
?>

<div class="col-10 p-4">
    <h4>Data Supplier</h4>

    <a href="supplier_tambah.php" class="btn btn-primary mb-3">
        + Tambah Supplier
    </a>

    <table class="table table-bordered table-striped">
        <tr>
            <th>No</th>
            <th>Nama Supplier</th>
            <th>Alamat</th>
            <th>No Telp</th>
            <th>Aksi</th>
        </tr>

        <?php $no=1; while($row = mysqli_fetch_assoc($data)): ?>
        <tr>
            <td><?= $no++ ?></td>
            <td><?= $row['NamaSupplier'] ?></td>
            <td><?= $row['Alamat'] ?></td>
            <td><?= $row['No_Telp'] ?></td>
            <td>
                <a href="supplier_edit.php?id=<?= $row['SupplierID'] ?>"
                   class="btn btn-warning btn-sm">Edit</a>

                <a href="supplier_hapus.php?id=<?= $row['SupplierID'] ?>"
                   class="btn btn-danger btn-sm"
                   onclick="return confirm('Hapus supplier?')">
                   Hapus
                </a>
            </td>
        </tr>
        <?php endwhile; ?>
    </table>
</div>

<?php require_once "footer.php"; ?>
