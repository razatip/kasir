<?php
$halaman = basename($_SERVER['PHP_SELF']);
?>

<style>
/* ===== SIDEBAR DASAR ===== */
.sidebar {
    background: linear-gradient(180deg, #0f172a, #020617);
    color: #ffffff;
}

/* Header */
.sidebar-header {
    border-bottom: 1px solid rgba(255,255,255,0.15);
}

/* ===== LINK MENU ===== */
.sidebar .nav-link {
    color: #cbd5e1;
    padding: 12px 16px;
    border-radius: 10px;
    display: flex;
    align-items: center;
    gap: 10px;
    font-size: 14px;
    transition: all 0.25s ease;
}

/* Icon */
.sidebar .nav-link i {
    font-size: 16px;
}

/* Hover */
.sidebar .nav-link:hover {
    background: rgba(255,255,255,0.12);
    color: #ffffff;
    transform: translateX(4px);
}

/* Active (halaman sedang dibuka) */
.sidebar .nav-link.active {
    background: #2563eb;
    color: #ffffff;
    font-weight: 500;
}

/* Logout khusus */
.sidebar .logout {
    color: #f87171;
}

.sidebar .logout:hover {
    background: rgba(248,113,113,0.18);
    color: #ffffff;
}
</style>

<div class="col-2 sidebar min-vh-100 p-0">
    <div class="sidebar-header text-center py-4">
        <h5 class="mb-0 fw-bold">ADMIN PANEL</h5>
    </div>

    <ul class="nav flex-column px-3 gap-1">

        <li class="nav-item">
            <a class="nav-link <?= $halaman=='index.php'?'active':'' ?>" href="index.php">
                <i class="bi bi-speedometer2"></i>
                Dashboard
            </a>
        </li>

        <li class="nav-item">
            <a class="nav-link <?= $halaman=='supplier.php'?'active':'' ?>" href="supplier.php">
                <i class="bi bi-truck"></i>
                Supplier
            </a>
        </li>

        <li class="nav-item">
            <a class="nav-link <?= $halaman=='barang.php'?'active':'' ?>" href="barang.php">
                <i class="bi bi-box-seam"></i>
                Barang
            </a>
        </li>

        <li class="nav-item">
            <a class="nav-link <?= $halaman=='pembelian.php'?'active':'' ?>" href="pembelian.php">
                <i class="bi bi-cart-check"></i>
                Pembelian
            </a>
        </li>
            <li class="nav-item">
    <a class="nav-link <?= $halaman=='pelanggan.php'?'active':'' ?>" href="pelanggan.php">
        <i class="bi bi-people"></i>
        Pelanggan
    </a>
        </li>
        <li class="nav-item mt-2">
            <small class="text-uppercase text-white px-2">Report</small>
        </li>

        <li class="nav-item">
            <a class="nav-link <?= $halaman=='laporan.php'?'active':'' ?>" href="laporan.php">
                <i class="bi bi-file-earmark-text"></i>
                Laporan
            </a>
        </li>

        <li class="nav-item mt-4">
<a class="nav-link logout logout-btn" href="../auth/logout.php">
                <i class="bi bi-box-arrow-left"></i>
                Logout
            </a>
        </li>

    </ul>
</div>
