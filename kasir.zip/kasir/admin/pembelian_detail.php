<?php
require_once __DIR__ . "/../main/auth.php";
cekRole('admin');
require_once __DIR__ . "/../main/connect.php";
require_once "header.php";
require_once "sidebar_admin.php";

$id = $_GET['id'];

// Ambil data pembelian
$pembelian = mysqli_fetch_assoc(mysqli_query($conn, "
    SELECT p.*, s.NamaSupplier, s.Alamat, s.No_Telp
    FROM pembelian p
    JOIN supplier s ON p.SupplierID = s.SupplierID
    WHERE p.pembelianID = '$id'
"));

// Ambil detail pembelian
$details = mysqli_query($conn, "
    SELECT dp.*, b.NamaBarang, b.Harga
    FROM detail_pembelian dp
    JOIN barang b ON dp.BarangID = b.BarangID
    WHERE dp.pembelianID = '$id'
");
?>

<div class="col-10 p-4">
    <h4>Detail Pembelian</h4>

    <div class="card shadow-sm mb-3">
        <div class="card-header bg-primary text-white">
            <h5 class="mb-0">Informasi Pembelian</h5>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-md-6">
                    <table class="table table-borderless">
                        <tr>
                            <td width="150"><strong>No Pembelian</strong></td>
                            <td>: <?= $pembelian['pembelianID'] ?></td>
                        </tr>
                        <tr>
                            <td><strong>Tanggal</strong></td>
                            <td>: <?= date('d/m/Y', strtotime($pembelian['TanggalPembelian'])) ?></td>
                        </tr>
                    </table>
                </div>
                <div class="col-md-6">
                    <table class="table table-borderless">
                        <tr>
                            <td width="150"><strong>Supplier</strong></td>
                            <td>: <?= $pembelian['NamaSupplier'] ?></td>
                        </tr>
                        <tr>
                            <td><strong>Alamat</strong></td>
                            <td>: <?= $pembelian['Alamat'] ?></td>
                        </tr>
                        <tr>
                            <td><strong>No Telp</strong></td>
                            <td>: <?= $pembelian['No_Telp'] ?></td>
                        </tr>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <div class="card shadow-sm">
        <div class="card-header bg-success text-white">
            <h5 class="mb-0">Detail Barang</h5>
        </div>
        <div class="card-body">
            <table class="table table-bordered table-striped">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Nama Barang</th>
                        <th>Harga Satuan</th>
                        <th>Jumlah</th>
                        <th>Subtotal</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    $no = 1;
                    $total = 0;
                    while ($detail = mysqli_fetch_assoc($details)) : 
                        $total += $detail['Subtotal'];
                    ?>
                    <tr>
                        <td><?= $no++ ?></td>
                        <td><?= $detail['NamaBarang'] ?></td>
                        <td>Rp <?= number_format($detail['Harga'], 0, ',', '.') ?></td>
                        <td><?= $detail['Jumlah'] ?></td>
                        <td>Rp <?= number_format($detail['Subtotal'], 0, ',', '.') ?></td>
                    </tr>
                    <?php endwhile; ?>
                    
                    <tr>
                        <td colspan="4" class="text-end"><strong>TOTAL</strong></td>
                        <td><strong>Rp <?= number_format($pembelian['TotalHarga'], 0, ',', '.') ?></strong></td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>

    <div class="mt-3">
        <a href="pembelian.php" class="btn btn-secondary">Kembali</a>
        <button onclick="window.print()" class="btn btn-info">
            <i class="bi bi-printer"></i> Cetak
        </button>
    </div>
</div>

<style>
@media print {
    .btn, nav, .col-2 { display: none !important; }
    .col-10 { width: 100% !important; max-width: 100% !important; }
}
</style>

<?php require_once "footer.php"; ?>