<?php
require_once __DIR__ . "/../main/auth.php";
cekRole('admin');
require_once __DIR__ . "/../main/connect.php";
require_once "header.php";
require_once "sidebar_admin.php";

// Hitung statistik
$total_supplier = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as total FROM supplier"))['total'];
$total_barang = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as total FROM barang"))['total'];
$total_pembelian = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as total FROM pembelian"))['total'];
$total_nilai_pembelian = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COALESCE(SUM(TotalHarga), 0) as total FROM pembelian"))['total'];

// stok barang habis/menipis
$stok_habis = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as total FROM barang WHERE stok = 0"))['total'];
$stok_menipis = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as total FROM barang WHERE stok > 0 AND stok <= 5"))['total'];

// Pembelian bulan ini
$bulan_ini = date('Y-m');
$pembelian_bulan_ini = mysqli_fetch_assoc(mysqli_query($conn, "
    SELECT COUNT(*) as total, COALESCE(SUM(TotalHarga), 0) as nilai 
    FROM pembelian 
    WHERE DATE_FORMAT(TanggalPembelian, '%Y-%m') = '$bulan_ini'
"));

// 5 Barang dengan stok terbanyak
$barang_terbanyak = mysqli_query($conn, "SELECT * FROM barang ORDER BY stok DESC LIMIT 5");

// 5 Pembelian terakhir
$pembelian_terakhir = mysqli_query($conn, "
    SELECT p.*, s.NamaSupplier 
    FROM pembelian p
    JOIN supplier s ON p.SupplierID = s.SupplierID
    ORDER BY p.TanggalPembelian DESC
    LIMIT 5
");

// Data untuk chart pembelian per bulan (6 bulan terakhir)
$chart_data = [];
for ($i = 5; $i >= 0; $i--) {
    $bulan = date('Y-m', strtotime("-$i month"));
    $bulan_label = date('M Y', strtotime("-$i month"));
    
    $data = mysqli_fetch_assoc(mysqli_query($conn, "
        SELECT COALESCE(SUM(TotalHarga), 0) as total 
        FROM pembelian 
        WHERE DATE_FORMAT(TanggalPembelian, '%Y-%m') = '$bulan'
    "));
    
    $chart_data[] = [
        'bulan' => $bulan_label,
        'total' => $data['total']
    ];
}
?>

<div class="col-10 p-4">
    <h4 class="mb-4">Dashboard Admin</h4>
    <p class="text-muted">Selamat datang di sistem inventaris Shopee</p>

    <!-- Card Statistik -->
    <div class="row mb-4">
        <div class="col-md-3">
            <div class="card text-white bg-primary shadow-sm">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="card-title mb-1">Total Supplier</h6>
                            <h2 class="mb-0"><?= $total_supplier ?></h2>
                        </div>
                        <div style="font-size: 3rem; opacity: 0.3;">
                            <i class="bi bi-people"></i>
                        </div>
                    </div>
                    <small>Supplier terdaftar</small>
                </div>
            </div>
        </div>

        <div class="col-md-3">
            <div class="card text-white bg-success shadow-sm">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="card-title mb-1">Total Barang</h6>
                            <h2 class="mb-0"><?= $total_barang ?></h2>
                        </div>
                        <div style="font-size: 3rem; opacity: 0.3;">
                            <i class="bi bi-box-seam"></i>
                        </div>
                    </div>
                    <small>Jenis barang</small>
                </div>
            </div>
        </div>

        <div class="col-md-3">
            <div class="card text-white bg-warning shadow-sm">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="card-title mb-1">Total Pembelian</h6>
                            <h2 class="mb-0"><?= $total_pembelian ?></h2>
                        </div>
                        <div style="font-size: 3rem; opacity: 0.3;">
                            <i class="bi bi-cart"></i>
                        </div>
                    </div>
                    <small>Transaksi pembelian</small>
                </div>
            </div>
        </div>

        <div class="col-md-3">
            <div class="card text-white bg-danger shadow-sm">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="card-title mb-1">Nilai Pembelian</h6>
                            <h2 class="mb-0" style="font-size: 1.3rem;">
                                Rp <?= number_format($total_nilai_pembelian / 1000000, 1) ?>Jt
                            </h2>
                        </div>
                        <div style="font-size: 3rem; opacity: 0.3;">
                            <i class="bi bi-currency-dollar"></i>
                        </div>
                    </div>
                    <small>Total nilai pembelian</small>
                </div>
            </div>
        </div>
    </div>

    <!-- Card Pembelian Bulan Ini & stok Alert -->
    <div class="row mb-4">
        <div class="col-md-6">
            <div class="card shadow-sm border-info">
                <div class="card-header bg-info text-white">
                    <h5 class="mb-0"><i class="bi bi-calendar-month"></i> Pembelian Bulan Ini</h5>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-6">
                            <h6 class="text-muted">Jumlah Transaksi</h6>
                            <h3 class="text-info"><?= $pembelian_bulan_ini['total'] ?></h3>
                        </div>
                        <div class="col-6">
                            <h6 class="text-muted">Total Nilai</h6>
                            <h3 class="text-info">Rp <?= number_format($pembelian_bulan_ini['nilai'], 0, ',', '.') ?></h3>
                        </div>
                    </div>
                    <hr>
                    <small class="text-muted">Periode: <?= date('F Y') ?></small>
                </div>
            </div>
        </div>

        <div class="col-md-6">
            <div class="card shadow-sm border-danger">
                <div class="card-header bg-danger text-white">
                    <h5 class="mb-0"><i class="bi bi-exclamation-triangle"></i> Alert stok Barang</h5>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-6">
                            <h6 class="text-muted">stok Habis</h6>
                            <h3 class="text-danger"><?= $stok_habis ?></h3>
                            <small class="text-muted">Barang dengan stok 0</small>
                        </div>
                        <div class="col-6">
                            <h6 class="text-muted">stok Menipis</h6>
                            <h3 class="text-warning"><?= $stok_menipis ?></h3>
                            <small class="text-muted">Barang dengan stok ≤ 5</small>
                        </div>
                    </div>
                    <hr>
                    <a href="barang.php" class="btn btn-sm btn-outline-danger">
                        <i class="bi bi-eye"></i> Lihat Detail stok
                    </a>
                </div>
            </div>
        </div>
    </div>

    <!-- Chart Pembelian -->
    <div class="row mb-4">
        <div class="col-md-12">
            <div class="card shadow-sm">
                <div class="card-header bg-primary text-white">
                    <h5 class="mb-0"><i class="bi bi-graph-up"></i> Grafik Pembelian 6 Bulan Terakhir</h5>
                </div>
                <div class="card-body">
                    <canvas id="chartPembelian" height="80"></canvas>
                </div>
            </div>
        </div>
    </div>

    <!-- Tabel Data -->
    <div class="row">
        <div class="col-md-6">
            <div class="card shadow-sm">
                <div class="card-header bg-success text-white">
                    <h5 class="mb-0"><i class="bi bi-box"></i> Top 5 Barang (stok Terbanyak)</h5>
                </div>
                <div class="card-body">
                    <table class="table table-sm table-hover">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Nama Barang</th>
                                <th>stok</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                            $no = 1;
                            while ($row = mysqli_fetch_assoc($barang_terbanyak)) : 
                            ?>
                            <tr>
                                <td><?= $no++ ?></td>
                                <td><?= $row['NamaBarang'] ?></td>
                                <td><span class="badge bg-success"><?= $row['stok'] ?></span></td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <div class="col-md-6">
            <div class="card shadow-sm">
                <div class="card-header bg-warning">
                    <h5 class="mb-0"><i class="bi bi-clock-history"></i> 5 Pembelian Terakhir</h5>
                </div>
                <div class="card-body">
                    <table class="table table-sm table-hover">
                        <thead>
                            <tr>
                                <th>Tanggal</th>
                                <th>Supplier</th>
                                <th>Total</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($row = mysqli_fetch_assoc($pembelian_terakhir)) : ?>
                            <tr>
                                <td><?= date('d/m/Y', strtotime($row['TanggalPembelian'])) ?></td>
                                <td><?= $row['NamaSupplier'] ?></td>
                                <td>Rp <?= number_format($row['TotalHarga'], 0, ',', '.') ?></td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                    <div class="text-center">
                        <a href="pembelian.php" class="btn btn-sm btn-outline-warning">
                            Lihat Semua Pembelian
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Chart.js -->
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
<script>
const ctx = document.getElementById('chartPembelian').getContext('2d');
const chartData = <?= json_encode($chart_data) ?>;

const myChart = new Chart(ctx, {
    type: 'bar',
    data: {
        labels: chartData.map(d => d.bulan),
        datasets: [{
            label: 'Total Pembelian (Rp)',
            data: chartData.map(d => d.total),
            backgroundColor: 'rgba(54, 162, 235, 0.5)',
            borderColor: 'rgba(54, 162, 235, 1)',
            borderWidth: 2
        }]
    },
    options: {
        responsive: true,
        plugins: {
            legend: {
                display: true,
                position: 'top'
            },
            tooltip: {
                callbacks: {
                    label: function(context) {
                        return 'Rp ' + context.parsed.y.toLocaleString('id-ID');
                    }
                }
            }
        },
        scales: {
            y: {
                beginAtZero: true,
                ticks: {
                    callback: function(value) {
                        return 'Rp ' + (value / 1000000).toFixed(1) + 'Jt';
                    }
                }
            }
        }
    }
});
</script>

<!-- Bootstrap Icons -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">

<?php require_once "footer.php"; ?>