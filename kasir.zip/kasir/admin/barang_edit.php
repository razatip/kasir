<?php
require_once __DIR__ . "/../main/auth.php";
cekRole('admin');
require_once __DIR__ . "/../main/connect.php";

// Ambil ID barang dari GET
$id = $_GET['id'] ?? '';
if (!$id) {
    die("ID barang tidak ditemukan!");
}

// --- PROSES UPDATE SEBELUM HTML ---
if (isset($_POST['update'])) {
    $nama  = mysqli_real_escape_string($conn, $_POST['nama']);
    $harga = (int) $_POST['harga']; // pastikan angka
    $stok  = (int) $_POST['stok'];

    $query = "
        UPDATE barang SET
        NamaBarang='$nama',
        Harga='$harga',
        stok='$stok'
        WHERE BarangID='$id'
    ";

    if (mysqli_query($conn, $query)) {
        header("Location: barang.php");
        exit;
    } else {
        die("Error updating record: " . mysqli_error($conn));
    }
}

// --- AMBIL DATA BARANG UNTUK FORM ---
$result = mysqli_query($conn, "SELECT * FROM barang WHERE BarangID='$id'");
if (!$result || mysqli_num_rows($result) == 0) {
    die("Barang tidak ditemukan!");
}
$data = mysqli_fetch_assoc($result);

// --- MULAI HTML ---
require_once "header.php";
require_once "sidebar_admin.php";
?>

<div class="col-10 p-4">
    <h4>Edit Barang</h4>

    <div class="card shadow-sm">
        <div class="card-body">
            <form method="POST">
                <div class="mb-3">
                    <label class="form-label">Nama Barang</label>
                    <input type="text" name="nama" class="form-control"
                           value="<?= htmlspecialchars($data['NamaBarang']) ?>" required>
                </div>

                <div class="mb-3">
                    <label class="form-label">Harga (angka saja)</label>
                    <input type="number" name="harga" class="form-control"
                           value="<?= htmlspecialchars($data['Harga']) ?>" required>
                </div>

                <div class="mb-3">
                    <label class="form-label">stok</label>
                    <input type="number" name="stok" class="form-control"
                           value="<?= htmlspecialchars($data['stok']) ?>" required>
                </div>

                <button name="update" class="btn btn-warning">
                    Update
                </button>
                <a href="barang.php" class="btn btn-secondary">
                    Kembali
                </a>
            </form>
        </div>
    </div>
</div>

<?php require_once "footer.php"; ?>
