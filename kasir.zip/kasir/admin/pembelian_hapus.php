<?php
require_once __DIR__ . "/../main/auth.php";
cekRole('admin');
require_once __DIR__ . "/../main/connect.php";

$id = $_GET['id'];

// Ambil detail pembelian untuk kembalikan stok
$details = mysqli_query($conn, "
    SELECT BarangID, Jumlah 
    FROM detail_pembelian 
    WHERE PembelianID = '$id'
");

// Kembalikan stok barang (kurangi stok)
while ($detail = mysqli_fetch_assoc($details)) {
    mysqli_query($conn, "
        UPDATE barang 
        SET Stok = Stok - {$detail['Jumlah']} 
        WHERE BarangID = '{$detail['BarangID']}'
    ");
}

// Hapus detail pembelian
mysqli_query($conn, "DELETE FROM detail_pembelian WHERE PembelianID = '$id'");

// Hapus pembelian
mysqli_query($conn, "DELETE FROM pembelian WHERE PembelianID = '$id'");

header("Location: pembelian.php");
exit;