<?php
require_once __DIR__ . "/../main/auth.php";
cekRole('admin');

require_once __DIR__ . "/../main/connect.php";
require_once "header.php";
require_once "sidebar_admin.php";

// Query disesuaikan dengan kolom NamaPelanggan, UangBayar, dan Kembalian di tabel penjualan
$query = mysqli_query($conn, "
    SELECT 
        p.PenjualanID, 
        p.Tanggal, 
        p.NamaPelanggan, 
        p.TotalHarga, 
        p.UangBayar, 
        p.Kembalian,
        SUM(d.Jumlah) as totalBarang
    FROM penjualan p
    LEFT JOIN detail_penjualan d ON p.PenjualanID = d.PenjualanID
    GROUP BY p.PenjualanID
    ORDER BY p.PenjualanID DESC
");
?>

<div class="col-10 p-4">
    <h3 class="mb-4">Data  Pelanggan</h3>

    <a href="pelanggan_tambah.php" class="btn btn-primary mb-3">+ Tambah  Pelanggan</a>

    <div class="card shadow-sm">
        <div class="card-body">
            <table class="table table-bordered table-hover">
                <thead class="table-dark">
                    <tr>
                        <th>No</th>
                        <th>Tanggal</th>
                        <th>Nama Pelanggan</th>
                        <th>Jumlah Barang</th>
                        <th>Total Harga</th>
                        <th>Uang Bayar</th>
                        <th>Kembalian</th>
                    </tr>
                </thead>
                <tbody>
                <?php 
                $no = 1; 
                while($row = mysqli_fetch_assoc($query)) { 
                ?>
                    <tr>
                        <td><?= $no++ ?></td>
                        <td><?= date('d/m/Y', strtotime($row['Tanggal'])) ?></td>
                        <td><?= htmlspecialchars($row['NamaPelanggan']) ?></td>
                        <td><?= $row['totalBarang'] ?: 0 ?></td>
                        <td>Rp <?= number_format($row['TotalHarga'], 0, ',', '.') ?></td>
                        <td>Rp <?= number_format($row['UangBayar'], 0, ',', '.') ?></td>
                        <td>Rp <?= number_format($row['Kembalian'], 0, ',', '.') ?></td>
                    </tr>
                <?php } ?>
                <?php if (mysqli_num_rows($query) == 0) : ?>
                    <tr>
                        <td colspan="7" class="text-center">Belum ada data transaksi.</td>
                    </tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>