-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 12, 2026 at 04:26 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `kasir`
--

-- --------------------------------------------------------

--
-- Table structure for table `barang`
--

CREATE TABLE `barang` (
  `BarangID` int(255) NOT NULL,
  `NamaBarang` varchar(255) NOT NULL,
  `Harga` int(255) NOT NULL,
  `stok` int(11) NOT NULL,
  `foto` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `barang`
--

INSERT INTO `barang` (`BarangID`, `NamaBarang`, `Harga`, `stok`, `foto`) VALUES
(2, 'kaos pria', 600000, 6, 'outfit4.jpg.jpeg'),
(3, 'kemejaa pria', 300000, 19, 'outfit.jpg.jpeg'),
(4, 'kaos wanita', 170000, 16, 'outfit8.jpg.jpeg');

-- --------------------------------------------------------

--
-- Table structure for table `detail_pembelian`
--

CREATE TABLE `detail_pembelian` (
  `DetailPembelianID` int(255) NOT NULL,
  `PembelianID` int(255) NOT NULL,
  `BarangID` int(255) NOT NULL,
  `Jumlah` int(255) NOT NULL,
  `Subtotal` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `detail_pembelian`
--

INSERT INTO `detail_pembelian` (`DetailPembelianID`, `PembelianID`, `BarangID`, `Jumlah`, `Subtotal`) VALUES
(1, 1, 4, 2, 340000);

-- --------------------------------------------------------

--
-- Table structure for table `detail_penjualan`
--

CREATE TABLE `detail_penjualan` (
  `DetailID` int(255) NOT NULL,
  `PenjualanID` int(255) NOT NULL,
  `BarangID` int(255) NOT NULL,
  `Jumlah` int(255) NOT NULL,
  `Harga` int(255) NOT NULL,
  `Subtotal` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `detail_penjualan`
--

INSERT INTO `detail_penjualan` (`DetailID`, `PenjualanID`, `BarangID`, `Jumlah`, `Harga`, `Subtotal`) VALUES
(2, 2, 2, 1, 600000, 600000),
(3, 3, 2, 1, 600000, 600000),
(4, 4, 2, 1, 600000, 600000),
(5, 8, 2, 4, 0, 2400000),
(6, 9, 3, 4, 0, 1200000),
(8, 11, 4, 3, 0, 510000),
(9, 15, 4, 1, 0, 170000),
(10, 16, 4, 2, 0, 340000),
(11, 17, 2, 1, 0, 600000),
(12, 18, 2, 2, 0, 1200000);

-- --------------------------------------------------------

--
-- Table structure for table `pembelian`
--

CREATE TABLE `pembelian` (
  `pembelianID` int(255) NOT NULL,
  `TanggalPembelian` date NOT NULL,
  `SupplierID` int(255) NOT NULL,
  `TotalHarga` int(255) NOT NULL,
  `UserID` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `pembelian`
--

INSERT INTO `pembelian` (`pembelianID`, `TanggalPembelian`, `SupplierID`, `TotalHarga`, `UserID`) VALUES
(1, '2026-02-11', 1, 340000, 16);

-- --------------------------------------------------------

--
-- Table structure for table `penjualan`
--

CREATE TABLE `penjualan` (
  `PenjualanID` int(255) NOT NULL,
  `Tanggal` date NOT NULL,
  `UserID` int(255) NOT NULL,
  `TotalHarga` int(255) NOT NULL,
  `NamaPelanggan` varchar(255) NOT NULL,
  `UangBayar` int(255) NOT NULL,
  `Kembalian` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `penjualan`
--

INSERT INTO `penjualan` (`PenjualanID`, `Tanggal`, `UserID`, `TotalHarga`, `NamaPelanggan`, `UangBayar`, `Kembalian`) VALUES
(2, '2026-02-11', 0, 600000, 'kiki', 0, 0),
(3, '2026-02-11', 0, 600000, 'kiki', 0, 0),
(4, '2026-02-11', 0, 600000, 'beni', 0, 0),
(5, '2026-02-11', 0, 3432, 'zahra', 1222, -2210),
(6, '2026-02-11', 0, 400000, 'dila', 5000000, 4600000),
(7, '2026-02-11', 0, 170000, 'zahra', 200000, 30000),
(8, '2026-02-12', 0, 2400000, 'zahra', 0, 0),
(9, '2026-02-12', 0, 1200000, 'zahra', 0, 0),
(11, '2026-02-12', 3, 510000, 'gilang', 0, 0),
(12, '2026-02-12', 0, 1200000, 'manda', 2000000, 800000),
(13, '2026-02-12', 0, 600000, 'zahra', 200000, -400000),
(14, '2026-02-12', 0, 170000, 'mini', 200000, 30000),
(15, '2026-02-12', 0, 170000, 'mini', 200000, 30000),
(16, '2026-02-12', 0, 340000, 'mili', 400000, 60000),
(17, '2026-02-12', 0, 600000, 'cici', 900000, 300000),
(18, '2026-02-12', 0, 1200000, 'didi', 3000000, 1800000);

-- --------------------------------------------------------

--
-- Table structure for table `supplier`
--

CREATE TABLE `supplier` (
  `SupplierID` int(255) NOT NULL,
  `NamaSupplier` varchar(255) NOT NULL,
  `Alamat` text NOT NULL,
  `No_Telp` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `supplier`
--

INSERT INTO `supplier` (`SupplierID`, `NamaSupplier`, `Alamat`, `No_Telp`) VALUES
(1, 'zahra', 'jln. kapausari 3', '081276548097'),
(2, 'yuda', 'jl.riau20', '082976435678');

-- --------------------------------------------------------

--
-- Table structure for table `transaksi`
--

CREATE TABLE `transaksi` (
  `BarangID` int(255) NOT NULL,
  `Jumlah` int(255) NOT NULL,
  `Total` decimal(15,2) NOT NULL,
  `Bank` varchar(255) NOT NULL,
  `RekeningUser` varchar(255) NOT NULL,
  `Tanggal` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `transaksi`
--

INSERT INTO `transaksi` (`BarangID`, `Jumlah`, `Total`, `Bank`, `RekeningUser`, `Tanggal`) VALUES
(4, 1, 170000.00, 'BCA', '234325', '2026-02-12 09:18:47.000000');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `UserID` int(255) NOT NULL,
  `Username` varchar(255) NOT NULL,
  `Password` varchar(255) NOT NULL,
  `Role` enum('admin','petugas','costumer') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`UserID`, `Username`, `Password`, `Role`) VALUES
(3, 'zahra', '$2y$10$d99kAY8NEOLCXdd3UrOjLuDTEDj9HVtQT4R5lPV4F4wLVCMHf18Bu', ''),
(4, 'athifa', '$2y$10$/rYAh1YpXahrHUzzoUHquu2miWriQKy/U1tYxG5cKRQFEPX90UKHa', 'petugas'),
(5, 'raka', '$2y$10$vm9upjZorcdmyQXr/Hr9/.wzJgr6t9KeE9qIS7m5ecrQ58PMGxWQa', 'petugas'),
(6, 'z', '$2y$10$NI8/G/ty0uwq5hpxUhjzxO93QLsEF3IXy73rhijWQsSAx.XRl.H0u', ''),
(7, 'l', '$2y$10$FkHtNiz7lJslJiLGYW3gAuXlXrGHcPerWMJqwwRSN4uk6sLCGgNuK', 'petugas'),
(8, 't', '$2y$10$/H7GfgGE1VEMUJnlS6Rx5uUCkrErVMBTlW5DwVZjUUG8AZHhT0kJu', ''),
(9, 'v', '$2y$10$yXhViRh8/7rp5diA9xYCwev25BBz1nbB0tRN/99C8bKudc32QLNx6', ''),
(10, 'o', '$2y$10$VzVzIn7YDzxDawPtRwjWL.XHQkONH80u8zKpKd/gFhkrRaytnyIte', ''),
(11, 'f', '$2y$10$mndFjv7dK/qz7pId8KbE4uW2UGjTB5dsIVU8YduT5vTikelJAHWRe', ''),
(12, 'k', '$2y$10$DJdaH8blDi/jDfRMPP3sHe/M3Ta.pfiO9xFbsauAlowBiGS2wvTK2', 'petugas'),
(13, 'b', '$2y$10$WzgBqP8fNkPVajtUbsz24eep3I/ECKU/99eqnPV.YTut5i8Ln/O4K', ''),
(14, 'r', '$2y$10$AAl/yGJDaJCG6YmVvMLdI.HaKsLpztNcx1q1sXCJtjW1lPSfimoXW', ''),
(15, 'c', '$2y$10$HU4KBUwmF2mxnj0G18101ueS.nW62M8iQgEKR6n9v9GXoC7WR5lbq', ''),
(16, 'e', '$2y$10$WmqzyZdmEZGxQFCRVuadluI7cRJhnmIW1RIZqb9TE0TNK8zhr/0Ny', 'admin'),
(17, 'yuda', '$2y$10$4vnsQZZU8VLKIRtW31jKguMCx2KiKiWwa50phyeCae5Scfo6v7Gha', ''),
(18, 'm', '$2y$10$18R030LpmuttjKRfT3a6BOKbc5Rxawp3u7txeUhHvp6jZuQKjnJHC', 'admin'),
(19, 'bibi', '$2y$10$bw4AA430aE1N6NDEkA.kSOyia.gbdYN2j7wbrqS0YAjPpb3H4yEeq', ''),
(20, 'yaya', '$2y$10$F4.irbjhJGEp.oI2M9drd.ZLPgyfeiZECm2QnZ2CRMh55tufa2ojm', ''),
(21, 'gigi', '$2y$10$r0bXTQsRfs2rCR30ueSuP.ZSF8WKezFqEf9ZzyeVy5rDs.cUl0yGS', ''),
(22, 'fr', '$2y$10$YB84BzAidmQV5AEvSMGTCeFyYkqsBEjmOUskJCVxeD/mkhNEpswzW', 'costumer'),
(23, 'zahraathifa', '$2y$10$3/OAB/QkqXf21TD1DmldDu454v8LZfSMoTKLeKroxXf5qWV6EBUFC', 'admin'),
(24, 'mini', '$2y$10$rnZXctaBVoNpfiN5dkZkfOUPYiilBom1HT6Af/p9MOeXIY3J3Lr6q', 'costumer'),
(25, 'qwin', '$2y$10$B2DE74d.BBwtxM.auu1vF.C7oB6Mbvk5clufgIpWyeCpH7RhvgnAW', 'costumer'),
(26, 'rara', '$2y$10$uf0lTdTcE3PX2Sk2U45CvuMLwVBIU2zpmn1xg6wig1Z1Xolibd9kS', 'costumer');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `barang`
--
ALTER TABLE `barang`
  ADD PRIMARY KEY (`BarangID`);

--
-- Indexes for table `detail_pembelian`
--
ALTER TABLE `detail_pembelian`
  ADD PRIMARY KEY (`DetailPembelianID`);

--
-- Indexes for table `detail_penjualan`
--
ALTER TABLE `detail_penjualan`
  ADD PRIMARY KEY (`DetailID`);

--
-- Indexes for table `pembelian`
--
ALTER TABLE `pembelian`
  ADD PRIMARY KEY (`pembelianID`);

--
-- Indexes for table `penjualan`
--
ALTER TABLE `penjualan`
  ADD PRIMARY KEY (`PenjualanID`);

--
-- Indexes for table `supplier`
--
ALTER TABLE `supplier`
  ADD PRIMARY KEY (`SupplierID`);

--
-- Indexes for table `transaksi`
--
ALTER TABLE `transaksi`
  ADD PRIMARY KEY (`BarangID`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`UserID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `barang`
--
ALTER TABLE `barang`
  MODIFY `BarangID` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `detail_pembelian`
--
ALTER TABLE `detail_pembelian`
  MODIFY `DetailPembelianID` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `detail_penjualan`
--
ALTER TABLE `detail_penjualan`
  MODIFY `DetailID` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `pembelian`
--
ALTER TABLE `pembelian`
  MODIFY `pembelianID` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `penjualan`
--
ALTER TABLE `penjualan`
  MODIFY `PenjualanID` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `supplier`
--
ALTER TABLE `supplier`
  MODIFY `SupplierID` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `transaksi`
--
ALTER TABLE `transaksi`
  MODIFY `BarangID` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `UserID` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
