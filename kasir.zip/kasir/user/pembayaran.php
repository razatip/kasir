<?php
require_once __DIR__ . "/../main/connect.php";

$id_barang = (int) $_POST['id_barang'];
$jumlah    = (int) $_POST['jumlah'];
$harga     = (int) $_POST['harga'];

$total = $jumlah * $harga;

$data = mysqli_query($conn, "SELECT * FROM barang WHERE BarangID = $id_barang");
$barang = mysqli_fetch_assoc($data);

if (!$barang) {
    die("Barang tidak ditemukan");
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Pembayaran</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

<style>
body { background-color: #f4f4f4; }

.page-wrapper { padding: 100px 0 200px; }

.page-title {
    font-size: 22px;
    font-weight: 600;
    margin-bottom: 30px;
}

.checkout-card {
    background: #fff;
    border-radius: 14px;
    padding: 30px;
    margin-bottom: 30px;
    box-shadow: 0 10px 30px rgba(0,0,0,.06);
}

.product-row {
    display: flex;
    align-items: center;
    gap: 20px;
}

.product-row img {
    width: 90px;
    height: 90px;
    border-radius: 10px;
    object-fit: cover;
}

.summary-row {
    display: flex;
    justify-content: space-between;
    margin-bottom: 10px;
}

.total-row {
    display: flex;
    justify-content: space-between;
    margin-top: 20px;
    padding-top: 20px;
    border-top: 1px dashed #ccc;
}

.total-price {
    font-size: 20px;
    font-weight: bold;
    color: #ff5722;
}

.btn-pay {
    background: #ff5722;
    color: #fff;
    border: none;
    padding: 10px;
    width: 100%;
    border-radius: 8px;
    font-weight: 600;
}

.btn-pay:hover { background: #e64a19; }

.receipt-box {
    background: #fafafa;
    border: 1px dashed #ccc;
    padding: 20px;
    border-radius: 10px;
    font-size: 14px;
}
</style>

<script>
function tampilRekening() {
    let bank = document.getElementById("bank").value;
    let rekeningText = "";

    if(bank === "BCA"){
        rekeningText = "BCA - 1234567890 a/n Toko Anda";
    } else if(bank === "BNI"){
        rekeningText = "BNI - 9876543210 a/n Toko Anda";
    } else if(bank === "BRI"){
        rekeningText = "BRI - 1122334455 a/n Toko Anda";
    }

    document.getElementById("infoRekening").innerHTML = rekeningText;
}
</script>

</head>
<body>

<div class="page-wrapper">
<div class="container">
<div class="row justify-content-center">
<div class="col-lg-6">

<div class="page-title">Checkout Pembayaran</div>

<!-- PRODUK -->
<div class="checkout-card">
<div class="fw-semibold mb-3">Produk</div>

<div class="product-row">
    <img src="../assets/img/<?= $barang['foto'] ?>">
    <div>
        <div class="fw-semibold"><?= $barang['NamaBarang'] ?></div>
        <div class="text-muted">Jumlah: <?= $jumlah ?> pcs</div>
    </div>
</div>
</div>

<!-- RINGKASAN -->
<div class="checkout-card">
<div class="fw-semibold mb-3">Ringkasan Pembayaran</div>

<div class="summary-row">
    <span>Harga</span>
    <span>Rp <?= number_format($harga,0,',','.') ?></span>
</div>

<div class="summary-row">
    <span>Jumlah</span>
    <span><?= $jumlah ?></span>
</div>

<div class="total-row">
    <span>Total</span>
    <span class="total-price">
        Rp <?= number_format($total,0,',','.') ?>
    </span>
</div>
</div>

<!-- PEMBAYARAN -->
<div class="checkout-card">
<div class="fw-semibold mb-3">Pembayaran</div>

<form method="POST" action="proses_bayar.php">

<input type="hidden" name="id_barang" value="<?= $id_barang ?>">
<input type="hidden" name="jumlah" value="<?= $jumlah ?>">
<input type="hidden" name="total" value="<?= $total ?>">
<input type="hidden" name="bank" id="bankHidden">

<div class="mb-3">
<label class="form-label">Pilih Bank</label>
<select class="form-control" name="bank" id="bank" onchange="tampilRekening()" required>
    <option value="">-- Pilih Bank --</option>
    <option value="BCA">BCA</option>
    <option value="BNI">BNI</option>
    <option value="BRI">BRI</option>
</select>
</div>

<div class="mb-3">
<label class="form-label">Nomor Rekening Anda</label>
<input type="text" name="rekening_user" class="form-control" required>
</div>

<div class="mb-3">
<div id="infoRekening" class="text-success fw-semibold"></div>
</div>

<hr>

<!-- STRUK -->
<div class="receipt-box">
<div class="fw-semibold mb-2">Struk Belanja</div>
Tanggal : <?= date("d-m-Y H:i") ?><br>
Produk : <?= $barang['NamaBarang'] ?><br>
Jumlah : <?= $jumlah ?><br>
Total  : Rp <?= number_format($total,0,',','.') ?><br>
</div>

<br>

<button class="btn-pay">Konfirmasi Pembayaran</button>

</form>
</div>

</div>
</div>
</div>
</div>

</body>
</html>
