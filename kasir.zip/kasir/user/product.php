<?php
session_start();
require_once __DIR__ . '/../main/connect.php';

if (!isset($_SESSION['login'])) {
    header("Location: ../auth/login.php");
    exit;
}

$barang = mysqli_query($conn, "SELECT * FROM barang WHERE stok > 0");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
<script src="https://cdn.tailwindcss.com"></script>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">

</head>
<body>
 <!-- NAVBAR -->
<nav class="bg-white shadow-lg sticky top-0 z-50">
  <div class="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">

    <!-- LOGO -->
    <a href="index.php" class="text-2xl font-bold tracking-wide">
      🛒 Fashionshop
    </a>

    <!-- MENU -->
    <ul class="hidden lg:flex items-center gap-10">
      <li>
        <a href="index.php" class="font-medium hover:text-gray-500 transition">
          Home
        </a>
      </li>
      <li>
        <a href="#produk" class="font-medium text-rose-900 transition">
          Product
        </a>
      </li>
      <li>
        <a href="../auth/logout.php"
           class="font-medium text-red-600 hover:text-red-700 transition">
          Logout
        </a>
      </li>
    </ul>

    <!-- SEARCH -->
    <div class="hidden lg:flex items-center">
      <div class="border rounded-full px-4 py-2 flex items-center gap-2">
        <input type="text"
               placeholder="Search Product"
               class="outline-none text-sm w-40">
      </div>
    </div>

  </div>
</nav>
<!-- ================= PRODUCT GRID ================= -->
<section id="produk" class="max-w-7xl mx-auto px-6 py-20">

  <div class="flex items-center justify-between mb-12">
    <h2 class="text-3xl font-bold">Our Products</h2>
    <p class="text-gray-500 text-sm">
      Discover our best collection curated just for you
    </p>
  </div>

  <div class="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-8">

    <?php while($row = mysqli_fetch_assoc($barang)) { ?>

    <!-- CARD -->
    <div class="group bg-white rounded-2xl overflow-hidden shadow-sm
                hover:shadow-2xl transition-all duration-300
                hover:-translate-y-1 flex flex-col">

      <!-- IMAGE -->
      <div class="relative overflow-hidden">
        <img src="../assets/img/<?= $row['foto']; ?>"
             class="w-full h-56 object-cover transition duration-300 group-hover:scale-105">

        <!-- STOCK BADGE -->
        <span class="absolute top-3 left-3 bg-white/90 text-xs font-semibold px-3 py-1 rounded-full">
          stok <?= $row['stok']; ?>
        </span>
      </div>

      <!-- CONTENT -->
      <div class="p-5 flex flex-col flex-grow">

        <h3 class="font-semibold text-sm mb-2 line-clamp-2">
          <?= $row['NamaBarang']; ?>
        </h3>

        <p class="text-rose-900 font-bold text-lg mb-4">
          Rp <?= number_format($row['Harga']); ?>
        </p>

        <!-- BUTTON -->
        <div class="mt-auto space-y-2">
          <a href="detail.php?id=<?= $row['BarangID']; ?>"
             class="block text-center border border-gray-200 rounded-full py-2 text-sm
                    hover:bg-gray-100 transition">
            Detail
          </a>

          <a href="beli_barang.php?id=<?= $row['BarangID']; ?>"
             class="block text-center bg-gray-900 text-white rounded-full py-2 text-sm
                    hover:bg-gray-800 transition">
            Beli Sekarang
          </a>
        </div>

      </div>
    </div>
    <!-- END CARD -->

    <?php } ?>

  </div>
</section>
<!-- ================= END PRODUCT GRID ================= -->
   
</body>
</html>