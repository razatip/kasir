<?php
require_once __DIR__ . "/../main/connect.php";

$id_barang = $_POST['id_barang'];
$jumlah = $_POST['jumlah'];
$total = $_POST['total'];
$bank = $_POST['bank'];
$rekening_user = $_POST['rekening_user'];

$data = mysqli_query($conn, "SELECT * FROM barang WHERE BarangID = $id_barang");
$barang = mysqli_fetch_assoc($data);

$tanggal = date("d/m/Y H:i:s");
$kode_transaksi = "TRX" . rand(10000,99999);
?>

<!DOCTYPE html>
<html>
<head>
<title>Struk Pembayaran</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

<style>
body{
    background:#eee;
    font-family: monospace;
}

.receipt{
    width:320px;
    background:#fff;
    margin:40px auto;
    padding:20px;
    box-shadow:0 0 10px rgba(0,0,0,.1);
    border-radius:10px;
}

.center{text-align:center;}
.line{border-top:1px dashed #000; margin:10px 0;}
.row-flex{
    display:flex;
    justify-content:space-between;
    font-size:14px;
}

.total{
    font-weight:bold;
    font-size:15px;
}

.btn-area{
    text-align:center;
    margin-top:20px;
}
</style>
</head>

<body>

<div class="receipt">

<div class="center">
    <h5>TOKO ANDA</h5>
    Jl. Contoh No.123<br>
    Telp: 08123456789
</div>

<div class="line"></div>

<div>
No Transaksi : <?= $kode_transaksi ?><br>
Tanggal      : <?= $tanggal ?><br>
Bank         : <?= $bank ?><br>
</div>

<div class="line"></div>

<div class="row-flex">
    <span><?= $barang['NamaBarang'] ?></span>
</div>

<div class="row-flex">
    <span><?= $jumlah ?> x Rp <?= number_format($barang['Harga'],0,',','.') ?></span>
    <span>Rp <?= number_format($total,0,',','.') ?></span>
</div>

<div class="line"></div>

<div class="row-flex total">
    <span>TOTAL</span>
    <span>Rp <?= number_format($total,0,',','.') ?></span>
</div>

<div class="line"></div>

Rek Pengirim:<br>
<?= $rekening_user ?>

<div class="line"></div>

<div class="center">
    *** TERIMA KASIH ***<br>
    Barang yang sudah dibeli<br>
    tidak dapat dikembalikan
</div>

<div class="btn-area">
    <button onclick="window.print()" class="btn btn-dark btn-sm">
        Print Struk
    </button>
    <br><br>
    <a href="../index.php" class="btn btn-secondary btn-sm">
        Kembali
    </a>
</div>

</div>

</body>
</html>
