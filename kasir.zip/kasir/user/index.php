<?php
session_start();
require_once __DIR__ . '/../main/connect.php';

if (!isset($_SESSION['login'])) {
    header("Location: ../auth/login.php");
    exit;
}

$barang = mysqli_query($conn, "SELECT * FROM barang WHERE stok > 0");
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Fashionshop</title>
<meta name="viewport" content="width=device-width, initial-scale=1">

<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
<script src="https://cdn.tailwindcss.com"></script>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">


<style>
body {
  font-family: 'Poppins', sans-serif;
}
</style>

</head>

<body class="bg-stone-100">


 <!-- NAVBAR -->
<nav class="bg-white shadow-lg sticky top-0 z-50">
  <div class="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">

    <!-- LOGO -->
    <a href="index.php" class="text-2xl font-bold tracking-wide">
      🛒 Fashionshop
    </a>

    <!-- MENU -->
    <ul class="hidden lg:flex items-center gap-10">
      <li>
        <a href="index.php" class="font-medium hover:text-gray-500 transition">
          Home
        </a>
      </li>
      <li>
        <a href="product.php" class="font-medium text-rose-900 transition">
          Product
        </a>
      </li>
      <li>
        <a href="../auth/logout.php"
           class="font-medium text-red-600 hover:text-red-700 transition">
          Logout
        </a>
      </li>
    </ul>

    <!-- SEARCH -->
    <div class="hidden lg:flex items-center">
      <div class="border rounded-full px-4 py-2 flex items-center gap-2">
        <input type="text"
               placeholder="Search Product"
               class="outline-none text-sm w-40">
      </div>
    </div>

  </div>
</nav>
<!-- ================= SLIDER ================= -->
<section class="relative w-full overflow-hidden bg-stone-100">

  <div id="slider"
       class="flex transition-transform duration-700 ease-in-out"
       style="transform: translateX(0%);">

    <!-- SLIDE 1 -->
    <div class="w-full flex flex-wrap p-10 flex-shrink-0">

      <div class="lg:w-5/12 p-2">
        <div class="mt-4 h-full">
          <h1 class="uppercase text-8xl lg:text-9xl mb-8">
            Fashion and Styles
          </h1>
         <p class="text-gray-500 text-lg font-semibold mb-10">
            Discover a Wide Range of Fashion Options </p>

          <div class="flex gap-4">
            <a href="product.php"
               class="bg-rose-900 rounded-full text-white px-8 h-12 inline-flex items-center">
              Shop Now
            </a>
            <a href="#produk"
               class="border rounded-full px-8 h-12 inline-flex items-center">
              Explore More
            </a>
          </div>
        </div>
      </div>

      <div class="lg:w-7/12 p-4">
        <div class="flex flex-wrap -m-4">
          <div class="w-full sm:w-8/12 p-4">
            <div class="h-[550px] overflow-hidden rounded-2xl">
              <img src="../assets/img/wome-poster.png"
                   class="w-full h-full object-cover">
            </div>
          </div>
          <div class="w-1/2 sm:w-2/12 p-4">
            <div class="h-[550px] overflow-hidden rounded-2xl">
              <img src="../assets/img/picture2.png"
                   class="w-full h-full object-cover">
            </div>
          </div>
          <div class="w-1/2 sm:w-2/12 p-4">
            <div class="h-[550px] overflow-hidden rounded-2xl">
              <img src="../assets/img/picture3.webp"
                   class="w-full h-full object-cover">
            </div>
          </div>
        </div>
      </div>

    </div>
  </div>
</section>


      <section class="relative">
          <div class="px-10 pb-10 pt-20">
       <div class="flex flex-wrap justify-between items-center gap-4 pb-10 border-b border-gray-200 mb-8">
    <h1 class="font-heading text-7xl uppercase">Discover our new arrival</h1>
    <!--  form search -->
<div class="hidden lg:flex gap-6">
  <div class="border border-black rounded-full py-3 px-5 flex items-center gap-4 focus-within:ring focus-within:ring-gray-100 transition duration-200 bg-white -ml-2">
    <a href="#" class="inline-block h-6">
      <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="none">
        <path d="M10.875 18.75C15.2242 18.75 18.75 15.2242 18.75 10.875C18.75 6.52576 15.2242 3 10.875 3C6.52576 3 3 6.52576 3 10.875C3 15.2242 6.52576 18.75 10.875 18.75Z" 
              stroke="black" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        <path d="M16.4438 16.4438L21.0001 21.0001" 
              stroke="black" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
      </svg>
    </a>
    <input 
      type="text" 
      class="flex-1 outline-none bg-transparent placeholder-gray-500 text-base pl-2" 
      placeholder="Search Product">
  </div>
</div>
  </div>
              <div class="flex flex-wrap -m-4">
                  <div class="w-full lg:w-1/3 p-4">
                      <div class="group">
                          <div class="relative overflow-hidden rounded-2xl mb-4" style="height:550px;">
                              <a href="#">
                                  <img class="rounded-2xl object-cover w-full h-full transform group-hover:scale-105 transition duration-200" src="../assets/img/children4.png" alt="">
                              </a>
                              <div class="absolute top-4 left-4 right-4">
                                  <div class="flex justify-between flex-wrap gap-4">
                                      <div class="flex flex-wrap gap-2">
                                          <div class="bg-white rounded-full px-3 py-2">
                                              <span class="block font-semibold">New arrival</span>
                                          </div>
                                          <div class="bg-white rounded-full px-3 py-2">
                                              <span class="block font-semibold text-red-600">30% OFF</span>
                                          </div>
                                      </div>
                                      <a href="#" class="bg-white border border-gray-200 rounded-full hover:bg-gray-50 focus:ring-4 focus:ring-gray-200 text-sm font-semibold w-10 h-10 flex items-center justify-center transition duration-200">
                                          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewbox="0 0 24 24" fill="none">
                                              <path d="M20.1603 5.00004C19.1002 3.93725 17.6951 3.28858 16.1986 3.17121C14.7021 3.05384 13.213 3.47551 12.0003 4.36004C10.7279 3.41368 9.14427 2.98455 7.5682 3.15908C5.99212 3.33361 4.54072 4.09882 3.50625 5.30063C2.47178 6.50244 1.9311 8.05156 1.99308 9.63606C2.05506 11.2206 2.71509 12.7227 3.84028 13.84L10.0503 20.06C10.5703 20.5718 11.2707 20.8587 12.0003 20.8587C12.7299 20.8587 13.4303 20.5718 13.9503 20.06L20.1603 13.84C21.3279 12.6653 21.9832 11.0763 21.9832 9.42004C21.9832 7.76377 21.3279 6.17478 20.1603 5.00004ZM18.7503 12.46L12.5403 18.67C12.4696 18.7414 12.3855 18.798 12.2928 18.8367C12.2001 18.8753 12.1007 18.8953 12.0003 18.8953C11.8999 18.8953 11.8004 18.8753 11.7077 18.8367C11.615 18.798 11.5309 18.7414 11.4603 18.67L5.25028 12.43C4.46603 11.6284 4.02689 10.5515 4.02689 9.43004C4.02689 8.30858 4.46603 7.2317 5.25028 6.43004C6.04943 5.64103 7.12725 5.19861 8.25028 5.19861C9.3733 5.19861 10.4511 5.64103 11.2503 6.43004C11.3432 6.52377 11.4538 6.59817 11.5757 6.64893C11.6976 6.6997 11.8283 6.72584 11.9603 6.72584C12.0923 6.72584 12.223 6.6997 12.3449 6.64893C12.4667 6.59817 12.5773 6.52377 12.6703 6.43004C13.4694 5.64103 14.5472 5.19861 15.6703 5.19861C16.7933 5.19861 17.8711 5.64103 18.6703 6.43004C19.4653 7.22119 19.9189 8.29223 19.9338 9.41373C19.9488 10.5352 19.5239 11.618 18.7503 12.43V12.46Z" fill="#D62323"></path>
                                          </svg>
                                      </a>
                                  </div>
                              </div>
                          </div>
                      </div>
                      <div class="flex flex-wrap justify-between gap-4">
                          <div>
                              <h2 class="font-heading text-3xl mb-2">baju anak</h2>
                              <p class="text-red-700 text-lg font-semibold">$145.00</p>
                          </div>
                          <div class="flex items-start flex-wrap gap-2">
                              <a href="#" class="inline-block">
                                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewbox="0 0 24 24" fill="none">
                                      <rect x="0.5" y="0.5" width="23" height="23" rx="11.5" fill="#EFF0F3"></rect>
                                      <rect x="0.5" y="0.5" width="23" height="23" rx="11.5" stroke="#D7D9DF"></rect>
                                      <circle cx="12" cy="12" r="8" fill="#85C851"></circle>
                                  </svg>
                              </a>
                              <a href="#" class="inline-block">
                                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewbox="0 0 24 24" fill="none">
                                      <rect x="0.5" y="0.5" width="23" height="23" rx="11.5" fill="#EFF0F3"></rect>
                                      <rect x="0.5" y="0.5" width="23" height="23" rx="11.5" stroke="#D7D9DF"></rect>
                                      <circle cx="12" cy="12" r="8" fill="#FFB11A"></circle>
                                  </svg>
                              </a>
                              <a href="#" class="inline-block">
                                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewbox="0 0 24 24" fill="none">
                                      <rect x="0.5" y="0.5" width="23" height="23" rx="11.5" fill="#EFF0F3"></rect>
                                      <rect x="0.5" y="0.5" width="23" height="23" rx="11.5" stroke="#D7D9DF"></rect>
                                      <circle cx="12" cy="12" r="8" fill="#35384C"></circle>
                                  </svg>
                              </a>
                          </div>
                      </div>
                  </div>
                  <div class="w-full lg:w-1/3 p-4">
                      <div class="group">
                          <div class="relative overflow-hidden rounded-2xl mb-4" style="height:550px;">
                              <a href="#">
                                  <img class="rounded-2xl object-cover w-full h-full transform group-hover:scale-105 transition duration-200" src="../assets/img/man1.jpg" alt="">
                              </a>
                              <div class="absolute top-4 left-4 right-4">
                                  <div class="flex justify-between flex-wrap gap-4">
                                      <div class="flex flex-wrap gap-2">
                                          <div class="bg-white rounded-full px-3 py-2">
                                              <span class="block font-semibold">New arrival</span>
                                          </div>
                                          <div class="bg-white rounded-full px-3 py-2">
                                              <span class="block font-semibold text-red-600">30% OFF</span>
                                          </div>
                                      </div>
                                      <a href="#" class="bg-white border border-gray-200 rounded-full hover:bg-gray-50 focus:ring-4 focus:ring-gray-200 text-sm font-semibold w-10 h-10 flex items-center justify-center transition duration-200">
                                          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewbox="0 0 24 24" fill="none">
                                              <path d="M20.1603 5.00004C19.1002 3.93725 17.6951 3.28858 16.1986 3.17121C14.7021 3.05384 13.213 3.47551 12.0003 4.36004C10.7279 3.41368 9.14427 2.98455 7.5682 3.15908C5.99212 3.33361 4.54072 4.09882 3.50625 5.30063C2.47178 6.50244 1.9311 8.05156 1.99308 9.63606C2.05506 11.2206 2.71509 12.7227 3.84028 13.84L10.0503 20.06C10.5703 20.5718 11.2707 20.8587 12.0003 20.8587C12.7299 20.8587 13.4303 20.5718 13.9503 20.06L20.1603 13.84C21.3279 12.6653 21.9832 11.0763 21.9832 9.42004C21.9832 7.76377 21.3279 6.17478 20.1603 5.00004ZM18.7503 12.46L12.5403 18.67C12.4696 18.7414 12.3855 18.798 12.2928 18.8367C12.2001 18.8753 12.1007 18.8953 12.0003 18.8953C11.8999 18.8953 11.8004 18.8753 11.7077 18.8367C11.615 18.798 11.5309 18.7414 11.4603 18.67L5.25028 12.43C4.46603 11.6284 4.02689 10.5515 4.02689 9.43004C4.02689 8.30858 4.46603 7.2317 5.25028 6.43004C6.04943 5.64103 7.12725 5.19861 8.25028 5.19861C9.3733 5.19861 10.4511 5.64103 11.2503 6.43004C11.3432 6.52377 11.4538 6.59817 11.5757 6.64893C11.6976 6.6997 11.8283 6.72584 11.9603 6.72584C12.0923 6.72584 12.223 6.6997 12.3449 6.64893C12.4667 6.59817 12.5773 6.52377 12.6703 6.43004C13.4694 5.64103 14.5472 5.19861 15.6703 5.19861C16.7933 5.19861 17.8711 5.64103 18.6703 6.43004C19.4653 7.22119 19.9189 8.29223 19.9338 9.41373C19.9488 10.5352 19.5239 11.618 18.7503 12.43V12.46Z" fill="#D62323"></path>
                                          </svg>
                                      </a>
                                  </div>
                              </div>
                          </div>
                          <div class="flex flex-wrap justify-between gap-4">
                              <div>
                                  <h2 class="font-heading text-3xl mb-2">baju pria dewasa</h2>
                                  <p class="text-red-700 text-lg font-semibold">$145.00</p>
                              </div>
                              <div class="flex items-start flex-wrap gap-2">
                                  <a href="#" class="inline-block">
                                      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewbox="0 0 24 24" fill="none">
                                          <rect x="0.5" y="0.5" width="23" height="23" rx="11.5" fill="#EFF0F3"></rect>
                                          <rect x="0.5" y="0.5" width="23" height="23" rx="11.5" stroke="#D7D9DF"></rect>
                                          <circle cx="12" cy="12" r="8" fill="#85C851"></circle>
                                      </svg>
                                  </a>
                                  <a href="#" class="inline-block">
                                      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewbox="0 0 24 24" fill="none">
                                          <rect x="0.5" y="0.5" width="23" height="23" rx="11.5" fill="#EFF0F3"></rect>
                                          <rect x="0.5" y="0.5" width="23" height="23" rx="11.5" stroke="#D7D9DF"></rect>
                                          <circle cx="12" cy="12" r="8" fill="#FFB11A"></circle>
                                      </svg>
                                  </a>
                                  <a href="#" class="inline-block">
                                      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewbox="0 0 24 24" fill="none">
                                          <rect x="0.5" y="0.5" width="23" height="23" rx="11.5" fill="#EFF0F3"></rect>
                                          <rect x="0.5" y="0.5" width="23" height="23" rx="11.5" stroke="#D7D9DF"></rect>
                                          <circle cx="12" cy="12" r="8" fill="#35384C"></circle>
                                      </svg>
                                  </a>
                              </div>
                          </div>
                      </div>
                  </div>
                  <div class="w-full lg:w-1/3 p-4">
                      <div class="group">
                          <div class="relative overflow-hidden rounded-2xl mb-4" style="height:550px;">
                              <a href="#">
                                  <img class="rounded-2xl object-cover w-full h-full transform group-hover:scale-105 transition duration-200" src="../assets/img/jewellry1.png" alt="">
                              </a>
                              <div class="absolute top-4 left-4 right-4">
                                  <div class="flex justify-between flex-wrap gap-4">
                                      <div class="flex flex-wrap gap-2">
                                          <div class="bg-white rounded-full px-3 py-2">
                                              <span class="block font-semibold">New arrival</span>
                                          </div>
                                          <div class="bg-white rounded-full px-3 py-2">
                                              <span class="block font-semibold text-red-600">30% OFF</span>
                                          </div>
                                      </div>
                                      <a href="#" class="bg-white border border-gray-200 rounded-full hover:bg-gray-50 focus:ring-4 focus:ring-gray-200 text-sm font-semibold w-10 h-10 flex items-center justify-center transition duration-200">
                                          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewbox="0 0 24 24" fill="none">
                                              <path d="M20.1603 5.00004C19.1002 3.93725 17.6951 3.28858 16.1986 3.17121C14.7021 3.05384 13.213 3.47551 12.0003 4.36004C10.7279 3.41368 9.14427 2.98455 7.5682 3.15908C5.99212 3.33361 4.54072 4.09882 3.50625 5.30063C2.47178 6.50244 1.9311 8.05156 1.99308 9.63606C2.05506 11.2206 2.71509 12.7227 3.84028 13.84L10.0503 20.06C10.5703 20.5718 11.2707 20.8587 12.0003 20.8587C12.7299 20.8587 13.4303 20.5718 13.9503 20.06L20.1603 13.84C21.3279 12.6653 21.9832 11.0763 21.9832 9.42004C21.9832 7.76377 21.3279 6.17478 20.1603 5.00004ZM18.7503 12.46L12.5403 18.67C12.4696 18.7414 12.3855 18.798 12.2928 18.8367C12.2001 18.8753 12.1007 18.8953 12.0003 18.8953C11.8999 18.8953 11.8004 18.8753 11.7077 18.8367C11.615 18.798 11.5309 18.7414 11.4603 18.67L5.25028 12.43C4.46603 11.6284 4.02689 10.5515 4.02689 9.43004C4.02689 8.30858 4.46603 7.2317 5.25028 6.43004C6.04943 5.64103 7.12725 5.19861 8.25028 5.19861C9.3733 5.19861 10.4511 5.64103 11.2503 6.43004C11.3432 6.52377 11.4538 6.59817 11.5757 6.64893C11.6976 6.6997 11.8283 6.72584 11.9603 6.72584C12.0923 6.72584 12.223 6.6997 12.3449 6.64893C12.4667 6.59817 12.5773 6.52377 12.6703 6.43004C13.4694 5.64103 14.5472 5.19861 15.6703 5.19861C16.7933 5.19861 17.8711 5.64103 18.6703 6.43004C19.4653 7.22119 19.9189 8.29223 19.9338 9.41373C19.9488 10.5352 19.5239 11.618 18.7503 12.43V12.46Z" fill="#D62323"></path>
                                          </svg>
                                      </a>
                                  </div>
                              </div>
                          </div>
                          <div class="flex flex-wrap justify-between gap-4">
                              <div>
                                  <h2 class="font-heading text-3xl mb-2">kalung hati</h2>
                                  <p class="text-red-700 text-lg font-semibold">$145.00</p>
                              </div>
                              <div class="flex items-start flex-wrap gap-2">
                                  <a href="#" class="inline-block">
                                      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewbox="0 0 24 24" fill="none">
                                          <rect x="0.5" y="0.5" width="23" height="23" rx="11.5" fill="#EFF0F3"></rect>
                                          <rect x="0.5" y="0.5" width="23" height="23" rx="11.5" stroke="#D7D9DF"></rect>
                                          <circle cx="12" cy="12" r="8" fill="#85C851"></circle>
                                      </svg>
                                  </a>
                                  <a href="#" class="inline-block">
                                      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewbox="0 0 24 24" fill="none">
                                          <rect x="0.5" y="0.5" width="23" height="23" rx="11.5" fill="#EFF0F3"></rect>
                                          <rect x="0.5" y="0.5" width="23" height="23" rx="11.5" stroke="#D7D9DF"></rect>
                                          <circle cx="12" cy="12" r="8" fill="#FFB11A"></circle>
                                      </svg>
                                  </a>
                                  <a href="#" class="inline-block">
                                      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewbox="0 0 24 24" fill="none">
                                          <rect x="0.5" y="0.5" width="23" height="23" rx="11.5" fill="#EFF0F3"></rect>
                                          <rect x="0.5" y="0.5" width="23" height="23" rx="11.5" stroke="#D7D9DF"></rect>
                                          <circle cx="12" cy="12" r="8" fill="#35384C"></circle>
                                      </svg>
                                  </a>
                              </div>
                          </div>
                      </div>
                  </div>
              </div>
          </div>
      </section>

<section class="relative overflow-hidden">
  <div class="px-10 pb-10 pt-20">
    <!-- Header -->
    <div class="flex flex-wrap justify-between items-center gap-4 pb-10 border-b border-gray-200 mb-8">
      <h1 class="font-heading text-5xl md:text-7xl uppercase">Discover our new arrival</h1>

      <!-- Panah & link -->
      <div class="flex items-center gap-5 flex-wrap">
        <a href="#" class="group flex items-center gap-5">
          <span class="text-2xl text-gray-500 group-hover:text-gray-700 transition duration-200">
            See All Collection
          </span>
        </a>

        <!-- Tombol panah -->
        <button id="next-btn" class="bg-white shadow-lg rounded-full p-3 hover:bg-gray-100 transition">
          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
            <path d="M8.46 19.54L9.88 20.95L17.83 13L9.88 5.05L8.46 6.46L15 13L8.46 19.54Z" fill="black"/>
          </svg>
        </button>
      </div>
    </div>

    <!-- ✅ SLIDER -->
    <div class="overflow-hidden"> <!-- penting -->
      <div id="product-track" class="flex gap-8 transition-transform duration-500 ease-in-out">
        <!-- Item 1 -->

<div class="min-w-[300px] md:min-w-[350px] lg:min-w-[25%] p-1 group">
  <div class="relative overflow-hidden rounded-2xl mb-4 h-[430px]">
    <a href="#">
      <img class="rounded-2xl object-cover w-full h-full transform group-hover:scale-105 transition duration-300" 
           src="../assets/img/outfit.jpg.jpeg" alt="Vintage Denim Skirt Look">
    </a>

    <!-- Badge dan Tombol Love -->
    <div class="absolute top-4 left-4 right-4">
      <div class="flex justify-between flex-wrap gap-4">
        <!-- Badge -->
        <div class="flex flex-wrap gap-2">
          <div class="bg-white rounded-full px-3 py-2">
            <span class="block font-semibold">New arrival</span>
          </div>
          <div class="bg-white rounded-full px-3 py-2">
            <span class="block font-semibold text-red-600">30% OFF</span>
          </div>
        </div>

        <!-- Tombol Love -->
        <a href="#" class="bg-white border border-gray-200 rounded-full hover:bg-gray-50 focus:ring-4 focus:ring-gray-200 text-sm font-semibold w-10 h-10 flex items-center justify-center transition duration-200">
          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
            <path d="M20.1603 5.00004C19.1002 3.93725 17.6951 3.28858 16.1986 3.17121C14.7021 3.05384 13.213 3.47551 12.0003 4.36004C10.7279 3.41368 9.14427 2.98455 7.5682 3.15908C5.99212 3.33361 4.54072 4.09882 3.50625 5.30063C2.47178 6.50244 1.9311 8.05156 1.99308 9.63606C2.05506 11.2206 2.71509 12.7227 3.84028 13.84L10.0503 20.06C10.5703 20.5718 11.2707 20.8587 12.0003 20.8587C12.7299 20.8587 13.4303 20.5718 13.9503 20.06L20.1603 13.84C21.3279 12.6653 21.9832 11.0763 21.9832 9.42004C21.9832 7.76377 21.3279 6.17478 20.1603 5.00004Z" fill="#D62323"/>
          </svg>
        </a>
      </div>
    </div>
  </div>

  <!-- Nama & Harga Produk -->
  <h2 class="font-heading text-3xl mb-2">Kemeja denim </h2>
  <p class="text-red-700 text-lg font-semibold">$145.00</p>
</div>

        <!-- Item 2 -->
       
<div class="min-w-[300px] md:min-w-[350px] lg:min-w-[25%] p-1 group">
  <div class="relative overflow-hidden rounded-2xl mb-4 h-[430px]">
    <a href="#">
      <img class="rounded-2xl object-cover w-full h-full transform group-hover:scale-105 transition duration-300" 
           src="../assets/img/outfit3.jpg.jpeg" alt="Vintage Denim Skirt Look">
    </a>

    <!-- Badge dan Tombol Love -->
    <div class="absolute top-4 left-4 right-4">
      <div class="flex justify-between flex-wrap gap-4">
        <!-- Badge -->
        <div class="flex flex-wrap gap-2">
          <div class="bg-white rounded-full px-3 py-2">
            <span class="block font-semibold">New arrival</span>
          </div>
          <div class="bg-white rounded-full px-3 py-2">
            <span class="block font-semibold text-red-600">30% OFF</span>
          </div>
        </div>

        <!-- Tombol Love -->
        <a href="#" class="bg-white border border-gray-200 rounded-full hover:bg-gray-50 focus:ring-4 focus:ring-gray-200 text-sm font-semibold w-10 h-10 flex items-center justify-center transition duration-200">
          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
            <path d="M20.1603 5.00004C19.1002 3.93725 17.6951 3.28858 16.1986 3.17121C14.7021 3.05384 13.213 3.47551 12.0003 4.36004C10.7279 3.41368 9.14427 2.98455 7.5682 3.15908C5.99212 3.33361 4.54072 4.09882 3.50625 5.30063C2.47178 6.50244 1.9311 8.05156 1.99308 9.63606C2.05506 11.2206 2.71509 12.7227 3.84028 13.84L10.0503 20.06C10.5703 20.5718 11.2707 20.8587 12.0003 20.8587C12.7299 20.8587 13.4303 20.5718 13.9503 20.06L20.1603 13.84C21.3279 12.6653 21.9832 11.0763 21.9832 9.42004C21.9832 7.76377 21.3279 6.17478 20.1603 5.00004Z" fill="#D62323"/>
          </svg>
        </a>
      </div>
    </div>
  </div>

  <!-- Nama & Harga Produk -->
  <h2 class="font-heading text-3xl mb-2">Celana laki laki</h2>
  <p class="text-red-700 text-lg font-semibold">$145.00</p>
</div>

        <!-- Item 3 -->
       <!-- 🧱 Card Produk Full Style -->
<div class="min-w-[300px] md:min-w-[350px] lg:min-w-[25%] p-1 group">
  <div class="relative overflow-hidden rounded-2xl mb-4 h-[430px]">
    <a href="#">
      <img class="rounded-2xl object-cover w-full h-full transform group-hover:scale-105 transition duration-300" 
           src="../assets/img/download (8).jpg" alt="Vintage Denim Skirt Look">
    </a>

    <!-- Badge dan Tombol Love -->
    <div class="absolute top-4 left-4 right-4">
      <div class="flex justify-between flex-wrap gap-4">
        <!-- Badge -->
        <div class="flex flex-wrap gap-2">
          <div class="bg-white rounded-full px-3 py-2">
            <span class="block font-semibold">New arrival</span>
          </div>
          <div class="bg-white rounded-full px-3 py-2">
            <span class="block font-semibold text-red-600">30% OFF</span>
          </div>
        </div>

        <!-- Tombol Love -->
        <a href="#" class="bg-white border border-gray-200 rounded-full hover:bg-gray-50 focus:ring-4 focus:ring-gray-200 text-sm font-semibold w-10 h-10 flex items-center justify-center transition duration-200">
          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
            <path d="M20.1603 5.00004C19.1002 3.93725 17.6951 3.28858 16.1986 3.17121C14.7021 3.05384 13.213 3.47551 12.0003 4.36004C10.7279 3.41368 9.14427 2.98455 7.5682 3.15908C5.99212 3.33361 4.54072 4.09882 3.50625 5.30063C2.47178 6.50244 1.9311 8.05156 1.99308 9.63606C2.05506 11.2206 2.71509 12.7227 3.84028 13.84L10.0503 20.06C10.5703 20.5718 11.2707 20.8587 12.0003 20.8587C12.7299 20.8587 13.4303 20.5718 13.9503 20.06L20.1603 13.84C21.3279 12.6653 21.9832 11.0763 21.9832 9.42004C21.9832 7.76377 21.3279 6.17478 20.1603 5.00004Z" fill="#D62323"/>
          </svg>
        </a>
      </div>
    </div>
  </div>

  <!-- Nama & Harga Produk -->
  <h2 class="font-heading text-3xl mb-2">kemeja wanita</h2>
  <p class="text-red-700 text-lg font-semibold">$145.00</p>
</div>

        <!-- Item 4 -->
    <!-- 🧱 Card Produk Full Style -->
<div class="min-w-[300px] md:min-w-[350px] lg:min-w-[25%] p-1 group">
  <div class="relative overflow-hidden rounded-2xl mb-4 h-[430px]">
    <a href="#">
      <img class="rounded-2xl object-cover w-full h-full transform group-hover:scale-105 transition duration-300" 
           src="../assets/img/download (9).jpg" alt="Vintage Denim Skirt Look">
    </a>

    <!-- Badge dan Tombol Love -->
    <div class="absolute top-4 left-4 right-4">
      <div class="flex justify-between flex-wrap gap-4">
        <!-- Badge -->
        <div class="flex flex-wrap gap-2">
          <div class="bg-white rounded-full px-3 py-2">
            <span class="block font-semibold">New arrival</span>
          </div>
          <div class="bg-white rounded-full px-3 py-2">
            <span class="block font-semibold text-red-600">30% OFF</span>
          </div>
        </div>

        <!-- Tombol Love -->
        <a href="#" class="bg-white border border-gray-200 rounded-full hover:bg-gray-50 focus:ring-4 focus:ring-gray-200 text-sm font-semibold w-10 h-10 flex items-center justify-center transition duration-200">
          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
            <path d="M20.1603 5.00004C19.1002 3.93725 17.6951 3.28858 16.1986 3.17121C14.7021 3.05384 13.213 3.47551 12.0003 4.36004C10.7279 3.41368 9.14427 2.98455 7.5682 3.15908C5.99212 3.33361 4.54072 4.09882 3.50625 5.30063C2.47178 6.50244 1.9311 8.05156 1.99308 9.63606C2.05506 11.2206 2.71509 12.7227 3.84028 13.84L10.0503 20.06C10.5703 20.5718 11.2707 20.8587 12.0003 20.8587C12.7299 20.8587 13.4303 20.5718 13.9503 20.06L20.1603 13.84C21.3279 12.6653 21.9832 11.0763 21.9832 9.42004C21.9832 7.76377 21.3279 6.17478 20.1603 5.00004Z" fill="#D62323"/>
          </svg>
        </a>
      </div>
    </div>
  </div>

  <!-- Nama & Harga Produk -->
  <h2 class="font-heading text-3xl mb-2">Kemeja denim wanita</h2>
  <p class="text-red-700 text-lg font-semibold">$145.00</p>
</div>

        <!-- Item 5 -->
      <!-- 🧱 Card Produk Full Style -->
<div class="min-w-[300px] md:min-w-[350px] lg:min-w-[25%] p-1 group">
  <div class="relative overflow-hidden rounded-2xl mb-4 h-[430px]">
    <a href="#">
      <img class="rounded-2xl object-cover w-full h-full transform group-hover:scale-105 transition duration-300" 
           src="../assets/img/outfit5.jpg.jpeg" alt="Vintage Denim Skirt Look">
    </a>

    <!-- Badge dan Tombol Love -->
    <div class="absolute top-4 left-4 right-4">
      <div class="flex justify-between flex-wrap gap-4">
        <!-- Badge -->
        <div class="flex flex-wrap gap-2">
          <div class="bg-white rounded-full px-3 py-2">
            <span class="block font-semibold">New arrival</span>
          </div>
          <div class="bg-white rounded-full px-3 py-2">
            <span class="block font-semibold text-red-600">30% OFF</span>
          </div>
        </div>

        <!-- Tombol Love -->
        <a href="#" class="bg-white border border-gray-200 rounded-full hover:bg-gray-50 focus:ring-4 focus:ring-gray-200 text-sm font-semibold w-10 h-10 flex items-center justify-center transition duration-200">
          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
            <path d="M20.1603 5.00004C19.1002 3.93725 17.6951 3.28858 16.1986 3.17121C14.7021 3.05384 13.213 3.47551 12.0003 4.36004C10.7279 3.41368 9.14427 2.98455 7.5682 3.15908C5.99212 3.33361 4.54072 4.09882 3.50625 5.30063C2.47178 6.50244 1.9311 8.05156 1.99308 9.63606C2.05506 11.2206 2.71509 12.7227 3.84028 13.84L10.0503 20.06C10.5703 20.5718 11.2707 20.8587 12.0003 20.8587C12.7299 20.8587 13.4303 20.5718 13.9503 20.06L20.1603 13.84C21.3279 12.6653 21.9832 11.0763 21.9832 9.42004C21.9832 7.76377 21.3279 6.17478 20.1603 5.00004Z" fill="#D62323"/>
          </svg>
        </a>
      </div>
    </div>
  </div>

  <!-- Nama & Harga Produk -->
  <h2 class="font-heading text-3xl mb-2">celana beige pria</h2>
  <p class="text-red-700 text-lg font-semibold">$145.00</p>
</div>

        <!-- Item 6 -->
       <!-- 🧱 Card Produk Full Style -->
<div class="min-w-[300px] md:min-w-[350px] lg:min-w-[25%] p-1 group">
  <div class="relative overflow-hidden rounded-2xl mb-4 h-[430px]">
    <a href="#">
      <img class="rounded-2xl object-cover w-full h-full transform group-hover:scale-105 transition duration-300" 
           src="../assets/img/download (10).jpg" alt="Vintage Denim Skirt Look">
    </a>

    <!-- Badge dan Tombol Love -->
    <div class="absolute top-4 left-4 right-4">
      <div class="flex justify-between flex-wrap gap-4">
        <!-- Badge -->
        <div class="flex flex-wrap gap-2">
          <div class="bg-white rounded-full px-3 py-2">
            <span class="block font-semibold">New arrival</span>
          </div>
          <div class="bg-white rounded-full px-3 py-2">
            <span class="block font-semibold text-red-600">30% OFF</span>
          </div>
        </div>

        <!-- Tombol Love -->
        <a href="#" class="bg-white border border-gray-200 rounded-full hover:bg-gray-50 focus:ring-4 focus:ring-gray-200 text-sm font-semibold w-10 h-10 flex items-center justify-center transition duration-200">
          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
            <path d="M20.1603 5.00004C19.1002 3.93725 17.6951 3.28858 16.1986 3.17121C14.7021 3.05384 13.213 3.47551 12.0003 4.36004C10.7279 3.41368 9.14427 2.98455 7.5682 3.15908C5.99212 3.33361 4.54072 4.09882 3.50625 5.30063C2.47178 6.50244 1.9311 8.05156 1.99308 9.63606C2.05506 11.2206 2.71509 12.7227 3.84028 13.84L10.0503 20.06C10.5703 20.5718 11.2707 20.8587 12.0003 20.8587C12.7299 20.8587 13.4303 20.5718 13.9503 20.06L20.1603 13.84C21.3279 12.6653 21.9832 11.0763 21.9832 9.42004C21.9832 7.76377 21.3279 6.17478 20.1603 5.00004Z" fill="#D62323"/>
          </svg>
        </a>
      </div>
    </div>
  </div>

  <!-- Nama & Harga Produk -->
  <h2 class="font-heading text-3xl mb-2">kemeja pria</h2>
  <p class="text-red-700 text-lg font-semibold">$145.00</p>
</div>

        <!-- Item 7 -->
    <!-- 🧱 Card Produk Full Style -->
<div class="min-w-[300px] md:min-w-[350px] lg:min-w-[25%] p-1 group">
  <div class="relative overflow-hidden rounded-2xl mb-4 h-[430px]">
    <a href="#">
      <img class="rounded-2xl object-cover w-full h-full transform group-hover:scale-105 transition duration-300" 
           src="../assets/img/outfit6.jpg.jpeg" alt="Vintage Denim Skirt Look">
    </a>

    <!-- Badge dan Tombol Love -->
    <div class="absolute top-4 left-4 right-4">
      <div class="flex justify-between flex-wrap gap-4">
        <!-- Badge -->
        <div class="flex flex-wrap gap-2">
          <div class="bg-white rounded-full px-3 py-2">
            <span class="block font-semibold">New arrival</span>
          </div>
          <div class="bg-white rounded-full px-3 py-2">
            <span class="block font-semibold text-red-600">30% OFF</span>
          </div>
        </div>

        <!-- Tombol Love -->
        <a href="#" class="bg-white border border-gray-200 rounded-full hover:bg-gray-50 focus:ring-4 focus:ring-gray-200 text-sm font-semibold w-10 h-10 flex items-center justify-center transition duration-200">
          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
            <path d="M20.1603 5.00004C19.1002 3.93725 17.6951 3.28858 16.1986 3.17121C14.7021 3.05384 13.213 3.47551 12.0003 4.36004C10.7279 3.41368 9.14427 2.98455 7.5682 3.15908C5.99212 3.33361 4.54072 4.09882 3.50625 5.30063C2.47178 6.50244 1.9311 8.05156 1.99308 9.63606C2.05506 11.2206 2.71509 12.7227 3.84028 13.84L10.0503 20.06C10.5703 20.5718 11.2707 20.8587 12.0003 20.8587C12.7299 20.8587 13.4303 20.5718 13.9503 20.06L20.1603 13.84C21.3279 12.6653 21.9832 11.0763 21.9832 9.42004C21.9832 7.76377 21.3279 6.17478 20.1603 5.00004Z" fill="#D62323"/>
          </svg>
        </a>
      </div>
    </div>
  </div>

  <!-- Nama & Harga Produk -->
  <h2 class="font-heading text-3xl mb-2">jersey pria</h2>
  <p class="text-red-700 text-lg font-semibold">$145.00</p>
</div>

        <!-- Item 8 -->
<div class="min-w-[300px] md:min-w-[350px] lg:min-w-[25%] p-1 group">
  <div class="relative overflow-hidden rounded-2xl mb-4 h-[430px]">
    <a href="#">
      <img class="rounded-2xl object-cover w-full h-full transform group-hover:scale-105 transition duration-300" 
           src="../assets/img/man1.jpg" alt="Vintage Denim Skirt Look">
    </a>

    <!-- Badge dan Tombol Love -->
    <div class="absolute top-4 left-4 right-4">
      <div class="flex justify-between flex-wrap gap-4">
        <!-- Badge -->
        <div class="flex flex-wrap gap-2">
          <div class="bg-white rounded-full px-3 py-2">
            <span class="block font-semibold">New arrival</span>
          </div>
          <div class="bg-white rounded-full px-3 py-2">
            <span class="block font-semibold text-red-600">30% OFF</span>
          </div>
        </div>

        <!-- Tombol Love -->
        <a href="#" class="bg-white border border-gray-200 rounded-full hover:bg-gray-50 focus:ring-4 focus:ring-gray-200 text-sm font-semibold w-10 h-10 flex items-center justify-center transition duration-200">
          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
            <path d="M20.1603 5.00004C19.1002 3.93725 17.6951 3.28858 16.1986 3.17121C14.7021 3.05384 13.213 3.47551 12.0003 4.36004C10.7279 3.41368 9.14427 2.98455 7.5682 3.15908C5.99212 3.33361 4.54072 4.09882 3.50625 5.30063C2.47178 6.50244 1.9311 8.05156 1.99308 9.63606C2.05506 11.2206 2.71509 12.7227 3.84028 13.84L10.0503 20.06C10.5703 20.5718 11.2707 20.8587 12.0003 20.8587C12.7299 20.8587 13.4303 20.5718 13.9503 20.06L20.1603 13.84C21.3279 12.6653 21.9832 11.0763 21.9832 9.42004C21.9832 7.76377 21.3279 6.17478 20.1603 5.00004Z" fill="#D62323"/>
          </svg>
        </a>
      </div>
    </div>
  </div>
  <!-- Nama & Harga Produk -->
  <h2 class="font-heading text-3xl mb-2">kaos denim pria</h2>
  <p class="text-red-700 text-lg font-semibold">$145.00</p>
</div>
<!-- Item 5 -->
<div class="min-w-[300px] md:min-w-[350px] lg:min-w-[25%] p-1 group">
  <div class="relative overflow-hidden rounded-2xl mb-4 h-[430px]">
    <a href="#">
      <img class="rounded-2xl object-cover w-full h-full transform group-hover:scale-105 transition duration-300" 
           src="../assets/img/outfit7.jpg.jpeg" alt="Vintage Denim Skirt Look">
    </a>

    <!-- Badge dan Tombol Love -->
    <div class="absolute top-4 left-4 right-4">
      <div class="flex justify-between flex-wrap gap-4">
        <!-- Badge -->
        <div class="flex flex-wrap gap-2">
          <div class="bg-white rounded-full px-3 py-2">
            <span class="block font-semibold">New arrival</span>
          </div>
          <div class="bg-white rounded-full px-3 py-2">
            <span class="block font-semibold text-red-600">30% OFF</span>
          </div>
        </div>

        <!-- Tombol Love -->
        <a href="#" class="bg-white border border-gray-200 rounded-full hover:bg-gray-50 focus:ring-4 focus:ring-gray-200 text-sm font-semibold w-10 h-10 flex items-center justify-center transition duration-200">
          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
            <path d="M20.1603 5.00004C19.1002 3.93725 17.6951 3.28858 16.1986 3.17121C14.7021 3.05384 13.213 3.47551 12.0003 4.36004C10.7279 3.41368 9.14427 2.98455 7.5682 3.15908C5.99212 3.33361 4.54072 4.09882 3.50625 5.30063C2.47178 6.50244 1.9311 8.05156 1.99308 9.63606C2.05506 11.2206 2.71509 12.7227 3.84028 13.84L10.0503 20.06C10.5703 20.5718 11.2707 20.8587 12.0003 20.8587C12.7299 20.8587 13.4303 20.5718 13.9503 20.06L20.1603 13.84C21.3279 12.6653 21.9832 11.0763 21.9832 9.42004C21.9832 7.76377 21.3279 6.17478 20.1603 5.00004Z" fill="#D62323"/>
          </svg>
        </a>
      </div>
    </div>
  </div>
 <!-- Nama & Harga Produk -->
  <h2 class="font-heading text-3xl mb-2">celana pendek pria</h2>
  <p class="text-red-700 text-lg font-semibold">$145.00</p>
</div>
<!-- Item 9 -->
<div class="min-w-[300px] md:min-w-[350px] lg:min-w-[25%] p-1 group">
  <div class="relative overflow-hidden rounded-2xl mb-4 h-[430px]">
    <a href="#">
      <img class="rounded-2xl object-cover w-full h-full transform group-hover:scale-105 transition duration-300" 
           src="../assets/img/outfit8.jpg.jpeg" alt="Vintage Denim Skirt Look">
    </a>

    <!-- Badge dan Tombol Love -->
    <div class="absolute top-4 left-4 right-4">
      <div class="flex justify-between flex-wrap gap-4">
        <!-- Badge -->
        <div class="flex flex-wrap gap-2">
          <div class="bg-white rounded-full px-3 py-2">
            <span class="block font-semibold">New arrival</span>
          </div>
          <div class="bg-white rounded-full px-3 py-2">
            <span class="block font-semibold text-red-600">30% OFF</span>
          </div>
        </div>

        <!-- Tombol Love -->
        <a href="#" class="bg-white border border-gray-200 rounded-full hover:bg-gray-50 focus:ring-4 focus:ring-gray-200 text-sm font-semibold w-10 h-10 flex items-center justify-center transition duration-200">
          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
            <path d="M20.1603 5.00004C19.1002 3.93725 17.6951 3.28858 16.1986 3.17121C14.7021 3.05384 13.213 3.47551 12.0003 4.36004C10.7279 3.41368 9.14427 2.98455 7.5682 3.15908C5.99212 3.33361 4.54072 4.09882 3.50625 5.30063C2.47178 6.50244 1.9311 8.05156 1.99308 9.63606C2.05506 11.2206 2.71509 12.7227 3.84028 13.84L10.0503 20.06C10.5703 20.5718 11.2707 20.8587 12.0003 20.8587C12.7299 20.8587 13.4303 20.5718 13.9503 20.06L20.1603 13.84C21.3279 12.6653 21.9832 11.0763 21.9832 9.42004C21.9832 7.76377 21.3279 6.17478 20.1603 5.00004Z" fill="#D62323"/>
          </svg>
        </a>
      </div>
    </div>
  </div>
 <!-- Nama & Harga Produk -->
  <h2 class="font-heading text-3xl mb-2">kaos wanita</h2>
  <p class="text-red-700 text-lg font-semibold">$145.00</p>
</div>

      </div>
    </div>
  </div>
</section>



                
        <!--footer-->
<section class="pt-20 pb-30 bg-rose-950">
  <div class="container mx-auto px-4">
    <!-- Bagian atas -->
    <div class="pb-20  mb-4">
      <div class="flex flex-wrap -m-4">
        <!-- Logo & Deskripsi -->
        <div class="w-full lg:w-1/2 p-4">
          <a href="#" class="inline-block mb-6">
            <img class="h-36" src="images/07Oct24_Anis_Free_Upload___2_-removebg-preview.png" alt="">
          </a>
          <p class="text-stone-300">Elevate Your Shopping Experience</p>
        </div>

        <!-- Modefy -->
        <div class="w-full sm:w-1/3 lg:w-1/6 p-4">
          <p class="font-semibold text-white mb-6">Modefy</p>
          <ul class="flex flex-col gap-4">
            <li><a href="product.php" class="text-stone-300 hover:text-white transition duration-200">Products</a></li>
            <li><a href="#" class="text-stone-300 hover:text-white transition duration-200">Categories</a></li>
            <li><a href="#" class="text-stone-300 hover:text-white transition duration-200">About us</a></li>
            <li><a href="contact.html" class="text-stone-300 hover:text-white transition duration-200">Contact</a></li>
          </ul>
        </div>

        <!-- Explore -->
        <div class="w-full sm:w-1/3 lg:w-1/6 p-4">
          <p class="font-semibold text-white mb-6">Explore</p>
          <ul class="flex flex-col gap-4">
            <li><a href="#" class="text-stone-300 hover:text-white transition duration-200">New Arrivals</a></li>
            <li><a href="#" class="text-stone-300 hover:text-white transition duration-200">Best Sellers</a></li>
            <li><a href="#" class="text-stone-300 hover:text-white transition duration-200">Offers</a></li>
          </ul>
        </div>

        <!-- Help + Payment -->
        <div class="w-full sm:w-1/3 lg:w-1/6 p-4">
          <p class="font-semibold text-white mb-6">Help</p>
          <ul class="flex flex-col gap-4 mb-6">
            <li><a href="#" class="text-stone-300 hover:text-white transition duration-200">Customer Support</a></li>
            <li><a href="#" class="text-stone-300 hover:text-white transition duration-200">Track Order</a></li>
            <li><a href="#" class="text-stone-300 hover:text-white transition duration-200">Feedback</a></li>
          </ul>

          <!-- Logo payment -->
          <div class="flex flex-wrap gap-4">
            <img class="h-6" src="shopky-assets/logos/visa-logo.svg" alt="">
            <img class="h-6" src="shopky-assets/logos/mastercard-logo.svg" alt="">
            <img class="h-6" src="shopky-assets/logos/paypal-logo.svg" alt="">
            <img class="h-6" src="shopky-assets/logos/amex-logo.svg" alt="">
          </div>
        </div>
      </div>
    </div>

    <!-- Bagian bawah -->
    <div class="text-center">
      <p class="text-stone-100 pb-10">© 2025 Modefy</p>
    </div>
  </div>
</section>

 <script src="https://cdn.tailwindcss.com"></script>

<script>
  const track = document.getElementById('product-track');
  const nextBtn = document.getElementById('next-btn');
  let currentIndex = 0;

  function getItemWidth() {
    return track.children[0].offsetWidth + 32; // 32 = gap 2rem
  }

  function getVisibleItems() {
    return window.innerWidth >= 1024 ? 4 : window.innerWidth >= 768 ? 2 : 1;
  }

  function updateSlider() {
    const itemWidth = getItemWidth();
    track.style.transform = `translateX(-${currentIndex * itemWidth}px)`;
  }

  nextBtn.addEventListener('click', () => {
    const totalItems = track.children.length;
    const visibleItems = getVisibleItems();

    if (currentIndex < totalItems - visibleItems) {
      currentIndex++;
    } else {
      currentIndex = 0;
    }
    updateSlider();
  });

  window.addEventListener('resize', () => {
    currentIndex = 0;
    updateSlider();
  });
</script>







</body>
</html>
