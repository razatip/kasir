<?php
require_once __DIR__ . "/../main/connect.php";

$id = (int) $_GET['id'];
$data = mysqli_query($conn, "SELECT * FROM barang WHERE BarangID = $id");
$barang = mysqli_fetch_assoc($data);

if (!$barang) {
    die("Barang tidak ditemukan");
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Beli Barang</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

<style>
body {
    background-color: #f4f4f4;
}

/* JARAK KE BAWAH PANJANG */
.page-wrapper {
    padding-top: 140px;
    padding-bottom: 260px;
}

/* JUDUL */
.page-title {
    font-size: 22px;
    font-weight: 600;
    margin-bottom: 40px;
    color: #333;
}

/* CARD */
.checkout-card {
    background: #fff;
    border-radius: 14px;
    padding: 36px;
    margin-bottom: 40px;
    box-shadow: 0 10px 30px rgba(0,0,0,.06);
}

/* PRODUK */
.product-box {
    display: flex;
    gap: 20px;
    align-items: center;
}

.product-box img {
    width: 90px;
    height: 90px;
    object-fit: cover;
    border-radius: 10px;
    border: 1px solid #eee;
}

.product-name {
    font-size: 16px;
    font-weight: 600;
    margin-bottom: 4px;
}

.product-price {
    font-size: 18px;
    font-weight: 600;
    color: #ff5722;
}

.product-stock {
    font-size: 13px;
    color: #777;
}

/* FORM */
.form-section {
    margin-top: 25px;
}

.form-group {
    margin-bottom: 55px;
}

.form-label {
    font-size: 14px;
    font-weight: 500;
    margin-bottom: 8px;
}

.form-control {
    height: 46px;
    border-radius: 8px;
}

/* ACTION */
.action-area {
    margin-top: 70px;
}

.btn-pay {
    background: #ff5722;
    color: white;
    border: none;
    padding: 12px;
    font-size: 14px;
    font-weight: 600;
    border-radius: 8px;
    width: 100%;
}

.btn-pay:hover {
    background: #e64a19;
}

.btn-cancel {
    margin-top: 20px;
    padding: 11px;
    border-radius: 8px;
    width: 100%;
}
</style>
</head>

<body>

<div class="page-wrapper">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-6">

                <div class="page-title">
                    Checkout Produk
                </div>

                <!-- INFO PRODUK -->
                <div class="checkout-card">
                    <div class="mb-3 fw-semibold">Produk</div>

                    <div class="product-box">
                        <img src="../assets/img/<?= $barang['foto'] ?>">
                        <div>
                            <div class="product-name">
                                <?= $barang['NamaBarang'] ?>
                            </div>
                            <div class="product-price">
                                Rp <?= number_format($barang['Harga'],0,',','.') ?>
                            </div>
                            <div class="product-stock">
                                stok tersedia: <?= $barang['stok'] ?>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- FORM BELI -->
                <div class="checkout-card">
                    <div class="fw-semibold mb-4">Jumlah Pembelian</div>

                    <form method="POST" action="pembayaran.php" class="form-section">

                        <input type="hidden" name="id_barang" value="<?= $barang['BarangID'] ?>">
                        <input type="hidden" name="harga" value="<?= $barang['Harga'] ?>">

                        <div class="form-group">
                            <label class="form-label">Jumlah</label>
                            <input type="number"
                                   name="jumlah"
                                   class="form-control"
                                   min="1"
                                   max="<?= $barang['stok'] ?>"
                                   value="1"
                                   required>
                        </div>

                        <div class="action-area">
                            <button class="btn-pay">
                                Lanjut ke Pembayaran
                            </button>

                            <a href="product.php" class="btn btn-light btn-cancel">
                                Batal
                            </a>
                        </div>

                    </form>
                </div>

            </div>
        </div>
    </div>
</div>

</body>
</html>
