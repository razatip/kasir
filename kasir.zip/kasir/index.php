<?php
session_start();

if (!isset($_SESSION['login'])) {
    header("Location: auth/login.php");
    exit;
}

if ($_SESSION['role'] == 'admin') {
    header("Location: admin/index.php");
    exit;
}

if ($_SESSION['role'] == 'petugas') {
    header("Location: petugas/index.php");
    exit;
}
