<?php
require_once __DIR__ . "/../main/auth.php";
cekRole('petugas');
require_once __DIR__ . "/../main/connect.php";

$nama_user = $_SESSION['username'] ?? 'Petugas';

// ================= LOGIKA BACKEND (CRUD) =================

// 1. HAPUS DATA
if (isset($_GET['hapus'])) {
    $id = mysqli_real_escape_string($conn, $_GET['hapus']);
    // Hapus detail dulu karena relasi Foreign Key
    mysqli_query($conn, "DELETE FROM detail_penjualan WHERE PenjualanID='$id'");
    mysqli_query($conn, "DELETE FROM penjualan WHERE PenjualanID='$id'");
    
    header("Location: pelanggan.php?pesan=hapus");
    exit;
}

// 2. TAMBAH & EDIT DATA
if (isset($_POST['simpan'])) {
    $id           = $_POST['PenjualanID']; 
    $namaPel      = mysqli_real_escape_string($conn, $_POST['NamaPelanggan']);
    $tgl          = $_POST['Tanggal'];
    $barangID     = $_POST['BarangID'];
    $jml          = (int)$_POST['Jumlah'];
    
    // Ambil harga barang dari database
    $resBarang = mysqli_query($conn, "SELECT Harga FROM barang WHERE BarangID='$barangID'");
    $b = mysqli_fetch_assoc($resBarang);
    $hargaSatuan = $b['Harga'];
    $subtotal = $hargaSatuan * $jml;

    if (empty($id)) {
        // PROSES INSERT (Data Baru)
        $queryP = "INSERT INTO penjualan (Tanggal, NamaPelanggan, TotalHarga) VALUES ('$tgl', '$namaPel', '$subtotal')";
        if(mysqli_query($conn, $queryP)) {
            $newID = mysqli_insert_id($conn);
            mysqli_query($conn, "INSERT INTO detail_penjualan (PenjualanID, BarangID, Jumlah, Subtotal) VALUES ('$newID', '$barangID', '$jml', '$subtotal')");
            header("Location: pelanggan.php?pesan=tambah");
            exit;
        }
    } else {
        // PROSES UPDATE (Data Lama)
        mysqli_query($conn, "UPDATE penjualan SET Tanggal='$tgl', NamaPelanggan='$namaPel', TotalHarga='$subtotal' WHERE PenjualanID='$id'");
        mysqli_query($conn, "UPDATE detail_penjualan SET BarangID='$barangID', Jumlah='$jml', Subtotal='$subtotal' WHERE PenjualanID='$id'");
        header("Location: pelanggan.php?pesan=update");
        exit;
    }
}

// 3. AMBIL DATA UNTUK TABEL (ORDER BY DESC agar data terbaru di atas)
$query_data = mysqli_query($conn, "
    SELECT p.*, d.Jumlah, d.BarangID, b.NamaBarang, d.Subtotal 
    FROM penjualan p
    JOIN detail_penjualan d ON p.PenjualanID = d.PenjualanID
    JOIN barang b ON d.BarangID = b.BarangID
    ORDER BY p.PenjualanID DESC
");

// Ambil daftar barang untuk dropdown select
$barang_list = mysqli_query($conn, "SELECT * FROM barang");
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Modefyshop - Data Pelanggan</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <style>
        :root {
            --sidebar-bg: #0f172a;
            --sidebar-hover: #1e293b;
            --accent-color: #2563eb;
        }
        body { background:#f4f6f9; font-family: 'Segoe UI', sans-serif; overflow-x: hidden; }
        
        .sidebar { 
            width: 260px; height: 100vh; background: var(--sidebar-bg); 
            color: white; position: fixed; left: 0; top: 0; z-index: 1000;
        }
        .sidebar-header { padding: 20px; border-bottom: 1px solid #1e293b; }
        .sidebar .nav-link { 
            color: #cbd5e1; padding: 12px 20px; margin: 4px 15px;
            border-radius: 8px; display: flex; align-items: center; gap: 12px;
            text-decoration: none; transition: 0.3s;
        }
        .sidebar .nav-link:hover { background: var(--sidebar-hover); color: white; }
        .sidebar .nav-link.active { background: var(--accent-color); color: white; }
        
        .content { margin-left: 260px; padding: 30px; min-height: 100vh; }
        .card { border: none; border-radius: 12px; box-shadow: 0 4px 12px rgba(0,0,0,0.05); }
    </style>
</head>
<body>

<div class="sidebar">
    <div class="sidebar-header">
        <h4 class="mb-0"><i class="bi bi-shop text-primary"></i> Modefyshop</h4>
        <small class="text-muted">PETUGAS PANEL</small>
    </div>
    <div class="mt-3">
        <ul class="nav flex-column">
            <li class="nav-item"><a class="nav-link" href="index.php"><i class="bi bi-speedometer2"></i> Dashboard</a></li>
            <li class="nav-item"><a class="nav-link" href="penjualan.php"><i class="bi bi-cart"></i> Penjualan</a></li>
            <li class="nav-item"><a class="nav-link" href="produck.php"><i class="bi bi-box"></i> Data Produk</a></li>
            <li class="nav-item"><a class="nav-link active" href="pelanggan.php"><i class="bi bi-people"></i> Data Pelanggan</a></li>
            <li class="nav-item"><a class="nav-link" href="laporan.php"><i class="bi bi-graph-up"></i> Laporan</a></li>
            <div class="px-3 mt-4"><hr class="text-secondary"></div>
            <li class="nav-item"><a class="nav-link text-danger" href="../auth/logout.php"><i class="bi bi-box-arrow-left"></i> Keluar</a></li>
        </ul>
    </div>
</div>

<div class="content">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h2 class="fw-bold mb-0">Kelola Transaksi Pelanggan</h2>
            <p class="text-secondary">Riwayat belanja pelanggan terbaru</p>
        </div>
        <div class="d-flex align-items-center gap-3">
            <span class="text-secondary small">Petugas: <b><?= strtoupper($nama_user) ?></b></span>
            <button class="btn btn-primary px-4 shadow-sm" data-bs-toggle="modal" data-bs-target="#modalPelanggan" onclick="resetForm()">
                <i class="bi bi-plus-lg me-1"></i> Tambah Transaksi
            </button>
        </div>
    </div>

    <?php if(isset($_GET['pesan'])): ?>
        <div class="alert alert-success alert-dismissible fade show border-0 shadow-sm mb-4" role="alert">
            <i class="bi bi-check-circle-fill me-2"></i> Data berhasil <strong><?= htmlspecialchars($_GET['pesan']) ?></strong>.
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <div class="card p-3">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead class="table-light text-secondary">
                    <tr>
                        <th class="ps-3">TGL TRANSAKSI</th>
                        <th>NAMA PELANGGAN</th>
                        <th>BARANG</th>
                        <th class="text-center">QTY</th>
                        <th>TOTAL HARGA</th>
                        <th class="text-center pe-3">AKSI</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while($r = mysqli_fetch_assoc($query_data)) : ?>
                    <tr>
                        <td class="ps-3"><?= date('d/m/Y', strtotime($r['Tanggal'])) ?></td>
                        <td class="fw-bold"><?= htmlspecialchars($r['NamaPelanggan']) ?></td>
                        <td><?= $r['NamaBarang'] ?></td>
                        <td class="text-center"><?= $r['Jumlah'] ?></td>
                        <td><span class="text-primary fw-bold">Rp <?= number_format($r['TotalHarga'],0,',','.') ?></span></td>
                        <td class="text-center pe-3">
                            <button class="btn btn-sm btn-outline-warning" 
                                onclick="editData('<?= $r['PenjualanID'] ?>', '<?= $r['NamaPelanggan'] ?>', '<?= $r['Tanggal'] ?>', '<?= $r['BarangID'] ?>', '<?= $r['Jumlah'] ?>')">
                                <i class="bi bi-pencil"></i>
                            </button>
                            <a href="pelanggan.php?hapus=<?= $r['PenjualanID'] ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Hapus transaksi ini?')">
                                <i class="bi bi-trash"></i>
                            </a>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                    <?php if(mysqli_num_rows($query_data) == 0) : ?>
                        <tr><td colspan="6" class="text-center p-5 text-secondary">Belum ada transaksi.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<div class="modal fade" id="modalPelanggan" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 shadow-lg">
            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title fw-bold" id="modalTitle">Tambah Transaksi</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST">
                <div class="modal-body p-4">
                    <input type="hidden" name="PenjualanID" id="form-id">
                    <div class="mb-3">
                        <label class="form-label fw-bold small">NAMA PELANGGAN</label>
                        <input type="text" name="NamaPelanggan" id="form-nama" class="form-control form-control-lg" placeholder="Contoh: Budi Santoso" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-bold small">TANGGAL</label>
                        <input type="date" name="Tanggal" id="form-tgl" class="form-control" value="<?= date('Y-m-d') ?>" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-bold small">PILIH BARANG</label>
                        <select name="BarangID" id="form-barang" class="form-select" required>
                            <option value="">-- Pilih --</option>
                            <?php 
                            mysqli_data_seek($barang_list, 0);
                            while($b = mysqli_fetch_assoc($barang_list)) { 
                                echo "<option value='{$b['BarangID']}'>{$b['NamaBarang']} (Rp ".number_format($b['Harga'],0,',','.').")</option>";
                            } ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-bold small">JUMLAH (QTY)</label>
                        <input type="number" name="Jumlah" id="form-jml" class="form-control" min="1" required>
                    </div>
                </div>
                <div class="modal-footer bg-light">
                    <button type="button" class="btn btn-secondary px-3" data-bs-dismiss="modal">Batal</button>
                    <button type="submit" name="simpan" class="btn btn-primary px-4 fw-bold shadow-sm">Simpan Data</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
    const modalInstance = new bootstrap.Modal(document.getElementById('modalPelanggan'));

    function resetForm() {
        document.getElementById('modalTitle').innerText = "Tambah Transaksi";
        document.getElementById('form-id').value = "";
        document.getElementById('form-nama').value = "";
        document.getElementById('form-jml').value = "";
        document.getElementById('form-tgl').value = "<?= date('Y-m-d') ?>";
        document.getElementById('form-barang').value = "";
    }

    function editData(id, nama, tgl, barang, jml) {
        document.getElementById('modalTitle').innerText = "Edit Transaksi #" + id;
        document.getElementById('form-id').value = id;
        document.getElementById('form-nama').value = nama;
        document.getElementById('form-tgl').value = tgl;
        document.getElementById('form-barang').value = barang;
        document.getElementById('form-jml').value = jml;
        modalInstance.show();
    }
</script>
</body>
</html>