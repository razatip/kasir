<?php
require_once __DIR__ . "/../main/auth.php";
cekRole('petugas');
require_once __DIR__ . "/../main/connect.php";

$nama = $_SESSION['username'] ?? 'Petugas';
$barang = mysqli_query($conn,"SELECT * FROM barang ORDER BY NamaBarang ASC");
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Data Produk</title>
<meta name="viewport" content="width=device-width, initial-scale=1">

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">

<style>
body{
    background:#f4f6f9;
    font-family: 'Segoe UI', sans-serif;
}

/* SIDEBAR */
.sidebar{
    width:260px;
    min-height:100vh;
    background:linear-gradient(180deg,#0f172a,#0b1a33);
    color:white;
    position:fixed;
}

.sidebar .nav-link{
    color:#cbd5e1;
    padding:12px 18px;
    border-radius:12px;
    margin-bottom:5px;
}

.sidebar .nav-link:hover,
.sidebar .nav-link.active{
    background:#2563eb;
    color:white;
}

/* CONTENT */
.content{
    margin-left:260px;
    padding:30px;
}
</style>
</head>

<body>

<!-- ================= SIDEBAR ================= -->
<div class="sidebar p-3">
    <h4 class="mb-1"><i class="bi bi-shop"></i> Modefyshop</h4>
    <small class="text-secondary">PETUGAS</small>

    <hr class="border-secondary">

    <ul class="nav flex-column">
        <li class="nav-item">
            <a class="nav-link" href="index.php">
                <i class="bi bi-speedometer2"></i> Dashboard
            </a>
        </li>

        <li class="nav-item">
            <a class="nav-link" href="penjualan.php">
                <i class="bi bi-cart"></i> Penjualan
            </a>
        </li>

        <!-- ACTIVE -->
        <li class="nav-item">
            <a class="nav-link active" href="produk.php">
                <i class="bi bi-box"></i> Data Produk
            </a>
        </li>

        <li class="nav-item">
            <a class="nav-link" href="pelanggan.php">
                <i class="bi bi-people"></i> Data Pelanggan
            </a>
        </li>

        <li class="nav-item">
            <a class="nav-link" href="laporan.php">
                <i class="bi bi-graph-up"></i> Laporan
            </a>
        </li>

        <hr class="border-secondary">

        <li class="nav-item">
            <a class="nav-link text-danger" href="../auth/logout.php">
                <i class="bi bi-box-arrow-left"></i> Keluar
            </a>
        </li>
    </ul>
</div>
<!-- ================= END SIDEBAR ================= -->


<!-- ================= CONTENT ================= -->
<div class="content">

    <!-- HEADER -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2 class="text-primary">
            <i class="bi bi-box"></i> Data Produk
        </h2>
        <div>Halo, <b><?= strtoupper($nama) ?></b></div>
    </div>

    <div class="card shadow">
        <div class="card-body">

            <table class="table table-bordered table-hover">
                <thead class="table-primary">
                    <tr>
                        <th width="60">No</th>
                        <th>Nama Barang</th>
                        <th width="150">Harga</th>
                        <th width="120">stok</th>
                    </tr>
                </thead>
                <tbody>

                <?php 
                $no = 1;
                while($b = mysqli_fetch_assoc($barang)) { 
                ?>
                    <tr>
                        <td><?= $no++ ?></td>
                        <td><?= $b['NamaBarang'] ?></td>
                        <td>Rp <?= number_format($b['Harga'],0,',','.') ?></td>
                        <td>
                            <?php if($b['stok'] == 0) { ?>
                                <span class="badge bg-danger">Habis</span>
                            <?php } elseif($b['stok'] <= 5) { ?>
                                <span class="badge bg-warning text-dark"><?= $b['stok'] ?></span>
                            <?php } else { ?>
                                <span class="badge bg-success"><?= $b['stok'] ?></span>
                            <?php } ?>
                        </td>
                    </tr>
                <?php } ?>

                </tbody>
            </table>

        </div>
    </div>

</div>
<!-- ================= END CONTENT ================= -->

</body>
</html>
