<?php
require_once __DIR__ . "/../main/auth.php";
cekRole('petugas');
require_once __DIR__ . "/../main/connect.php";

$nama = $_SESSION['username'] ?? 'Petugas';

// contoh hitung (silakan sesuaikan dengan tabel asli)
$today = date('Y-m-d');

$transaksi_hari_ini = mysqli_fetch_assoc(mysqli_query($conn,
    "SELECT COUNT(*) as total FROM penjualan WHERE DATE(Tanggal)='$today'"
))['total'] ?? 0;

$total_penjualan = mysqli_fetch_assoc(mysqli_query($conn,
    "SELECT COALESCE(SUM(TotalHarga),0) as total FROM penjualan WHERE DATE(Tanggal)='$today'"
))['total'] ?? 0;

$transaksi_terakhir = mysqli_query($conn,
    "SELECT * FROM penjualan ORDER BY Tanggal DESC LIMIT 5"
);
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Dashboard Petugas</title>
<meta name="viewport" content="width=device-width, initial-scale=1">

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">

<style>
body{
    background:#f4f6f9;
    font-family: 'Segoe UI', sans-serif;
}

/* SIDEBAR */
.sidebar{
    width:260px;
    min-height:100vh;
    background:linear-gradient(180deg,#0f172a,#0b1a33);
    color:white;
    position:fixed;
}

.sidebar .nav-link{
    color:#cbd5e1;
    padding:12px 18px;
    border-radius:12px;
    margin-bottom:5px;
}

.sidebar .nav-link:hover,
.sidebar .nav-link.active{
    background:#2563eb;
    color:white;
}

/* CONTENT */
.content{
    margin-left:260px;
    padding:30px;
}

/* WELCOME CARD */
.welcome{
    background:linear-gradient(135deg,#1e3a8a,#2563eb);
    color:white;
    border-radius:20px;
    padding:25px;
}

/* INFO CARD */
.info-card{
    border-radius:18px;
}
</style>
</head>

<body>

<!-- SIDEBAR -->
<div class="sidebar p-3">
    <h4 class="mb-1"><i class="bi bi-shop"></i> Modefyshop</h4>
    <small class="text-secondary">PETUGAS</small>

    <hr class="border-secondary">

    <ul class="nav flex-column">
        <li class="nav-item">
            <a class="nav-link active" href="#">
                <i class="bi bi-speedometer2"></i> Dashboard
            </a>
        </li>

        <li class="nav-item">
            <a class="nav-link" href="penjualan.php">
                <i class="bi bi-cart"></i> Penjualan
            </a>
        </li>

        <li class="nav-item">
            <a class="nav-link" href="produck.php">
                <i class="bi bi-box"></i> Data Produk
            </a>
        </li>

        <li class="nav-item">
            <a class="nav-link" href="penjualan.php">
                <i class="bi bi-people"></i> Data Pelanggan
            </a>
        </li>

        <li class="nav-item">
            <a class="nav-link" href="laporan.php">
                <i class="bi bi-graph-up"></i> Laporan
            </a>
        </li>

        <hr class="border-secondary">

        <li class="nav-item">
            <a class="nav-link text-danger" href="../auth/logout.php">
                <i class="bi bi-box-arrow-left"></i> Keluar
            </a>
        </li>
    </ul>
</div>

<!-- CONTENT -->
<div class="content">

    <!-- HEADER -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2 class="text-primary">
            <i class="bi bi-speedometer2"></i> Dashboard Petugas
        </h2>
        <div>Halo, <b><?= strtoupper($nama) ?></b></div>
    </div>

    <!-- WELCOME -->
    <div class="welcome shadow mb-4">
        <h4><i class="bi bi-person-check"></i> Selamat Bekerja</h4>
        <p class="mb-0">Layani pelanggan dengan sepenuh hati hari ini</p>
    </div>

    <!-- STAT -->
    <div class="row mb-4">
        <div class="col-md-6">
            <div class="card info-card shadow">
                <div class="card-body">
                    <small class="text-muted">TRANSAKSI HARI INI</small>
                    <h3><?= $transaksi_hari_ini ?> Nota</h3>
                </div>
            </div>
        </div>

        <div class="col-md-6">
            <div class="card info-card shadow">
                <div class="card-body">
                    <small class="text-muted">TOTAL PENJUALAN</small>
                    <h3>Rp <?= number_format($total_penjualan,0,',','.') ?></h3>
                </div>
            </div>
        </div>
    </div>

    <!-- TRANSAKSI TERAKHIR -->
    <div class="card shadow">
        <div class="card-header">
            <b><i class="bi bi-clock-history"></i> Transaksi Terakhir</b>
        </div>
        <div class="card-body">
            <table class="table">
                <thead>
                    <tr>
                        <th>Waktu</th>
                        <th>Total</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while($row = mysqli_fetch_assoc($transaksi_terakhir)) { ?>
                    <tr>
                        <td><?= $row['Tanggal'] ?></td>
                        <td>Rp <?= number_format($row['TotalHarga'],0,',','.') ?></td>
                    </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>

</div>

</body>
</html>
