<?php
require_once "../main/connect.php";

// Pastikan data dikirim melalui method POST
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    
    // 1. AMBIL DATA DARI FORM
    $nama    = mysqli_real_escape_string($conn, $_POST['nama']);
    $total   = (int) $_POST['total'];
    $bayar   = (int) $_POST['bayar'];
    $tgl     = date('Y-m-d H:i:s'); // Mengambil waktu sekarang

    // Hitung kembalian
    $kembali = $bayar - $total;

    // Cek jika uang bayar kurang
    if ($bayar < $total) {
        echo "<script>alert('Uang bayar tidak cukup!'); window.history.back();</script>";
        exit;
    }

    // 2. SIMPAN KE TABEL PENJUALAN (HEADER)
    // Pastikan kolom UangBayar dan Kembalian sudah ada di struktur tabel penjualan Anda
    $query_p = "INSERT INTO penjualan (Tanggal, NamaPelanggan, TotalHarga, UangBayar, Kembalian) 
                VALUES ('$tgl', '$nama', '$total', '$bayar', '$kembali')";
    
    if (mysqli_query($conn, $query_p)) {
        
        // Ambil ID penjualan yang baru saja dibuat
        $penjualan_id = mysqli_insert_id($conn);

        // 3. AMBIL DATA BARANG DARI ARRAY INPUT
        $barang_ids = $_POST['barang_id'];
        $jumlahs    = $_POST['jumlah'];

        // Looping untuk menyimpan setiap barang yang dipilih ke tabel detail
        for ($i = 0; $i < count($barang_ids); $i++) {
            $id_b = mysqli_real_escape_string($conn, $barang_ids[$i]);
            $qty  = (int) $jumlahs[$i];

            // Abaikan jika ID barang kosong atau jumlah 0
            if (empty($id_b) || $qty <= 0) continue;

            // Ambil harga barang satuan dari database untuk menghitung subtotal detail
            $res_h = mysqli_query($conn, "SELECT Harga FROM barang WHERE BarangID = '$id_b'");
            $data_h = mysqli_fetch_assoc($res_h);
            $harga_satuan = $data_h['Harga'];
            $subtotal = $harga_satuan * $qty;

            // 4. SIMPAN KE TABEL DETAIL_PENJUALAN
            // Langkah ini wajib agar data muncul di halaman pelanggan.php (karena pakai JOIN)
            $query_d = "INSERT INTO detail_penjualan (PenjualanID, BarangID, Jumlah, Subtotal) 
                        VALUES ('$penjualan_id', '$id_b', '$qty', '$subtotal')";
            mysqli_query($conn, $query_d);

            // 5. UPDATE STOK BARANG (POTONG STOK)
            $query_stok = "UPDATE barang SET Stok = Stok - $qty WHERE BarangID = '$id_b'";
            mysqli_query($conn, $query_stok);
        }

        // 6. REDIRECT KE NOTA
        // Data Beni sekarang sudah aman di database dan akan muncul di tabel pelanggan
        header("Location: nota.php?id=$penjualan_id");
        exit;

    } else {
        // Tampilkan error jika query utama gagal
        echo "Gagal menyimpan transaksi: " . mysqli_error($conn);
    }

} else {
    // Jika mencoba akses file ini tanpa POST, kembalikan ke form
    header("Location: penjualan.php");
    exit;
}
?>