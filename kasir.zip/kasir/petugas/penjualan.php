<?php
require_once "../main/connect.php";

// Ambil semua barang dari database
$barang = mysqli_query($conn, "SELECT * FROM barang ORDER BY NamaBarang ASC");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Form Penjualan</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        body{
            background:#f4f6f9;
            font-family: 'Segoe UI', sans-serif;
        }

        /* SIDEBAR */
        .sidebar{
            width:260px;
            min-height:100vh;
            background:linear-gradient(180deg,#0f172a,#0b1a33);
            color:white;
            position:fixed;
        }

        .sidebar .nav-link{
            color:#cbd5e1;
            padding:12px 18px;
            border-radius:12px;
            margin-bottom:5px;
        }

        .sidebar .nav-link:hover,
        .sidebar .nav-link.active{
            background:#2563eb;
            color:white;
        }

        /* CONTENT */
        .content{
            margin-left:260px;
            padding:30px;
        }

        /* FORM */
        .card{
            padding:20px;
            border-radius:12px;
            box-shadow: 0 8px 20px rgba(0,0,0,0.1);
            background:white;
        }
        table td, table th{
            vertical-align: middle;
        }
    </style>
</head>
<body>

<!-- ================= SIDEBAR ================= -->
<div class="sidebar p-3">
    <h4 class="mb-1"><i class="bi bi-shop"></i> Modefyshop</h4>
    <small class="text-secondary">PETUGAS</small>

    <hr class="border-secondary">

    <ul class="nav flex-column">
        <li class="nav-item">
            <a class="nav-link" href="index.php">
                <i class="bi bi-speedometer2"></i> Dashboard
            </a>
        </li>

        <li class="nav-item">
            <a class="nav-link active" href="penjualan.php">
                <i class="bi bi-cart"></i> Penjualan
            </a>
        </li>

        <li class="nav-item">
            <a class="nav-link" href="produck.php">
                <i class="bi bi-box"></i> Data Produk
            </a>
        </li>

        <li class="nav-item">
            <a class="nav-link" href="pelanggan.php">
                <i class="bi bi-people"></i> Data Pelanggan
            </a>
        </li>

        <li class="nav-item">
            <a class="nav-link" href="laporan.php">
                <i class="bi bi-graph-up"></i> Laporan
            </a>
        </li>

        <hr class="border-secondary">

        <li class="nav-item">
            <a class="nav-link text-danger" href="../auth/logout.php">
                <i class="bi bi-box-arrow-left"></i> Keluar
            </a>
        </li>
    </ul>
</div>
<!-- ================= END SIDEBAR ================= -->

<!-- ================= CONTENT ================= -->
<div class="content">
    <h4>Form Penjualan</h4>
    <div class="card">
        <form method="post" action="proses_penjualan.php" id="penjualanForm">
            <div class="mb-3">
                <label>Nama Pelanggan</label>
                <input type="text" name="nama" class="form-control" placeholder="Masukkan nama pelanggan" required>
            </div>

            <h5>Daftar Barang</h5>
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>Barang</th>
                        <th>Harga</th>
                        <th>Jumlah</th>
                        <th>Subtotal</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody id="barangBody">
                    <tr>
                        <td>
                            <select class="form-control barang-select" name="barang_id[]" required>
                                <option value="">-- Pilih Barang --</option>
                                <?php while($b = mysqli_fetch_assoc($barang)) { ?>
                                    <option value="<?= $b['BarangID'] ?>" data-harga="<?= $b['Harga'] ?>">
                                        <?= $b['NamaBarang'] ?>
                                    </option>
                                <?php } ?>
                            </select>
                        </td>
                        <td>
                            <input type="text" class="form-control harga" readonly value="0">
                        </td>
                        <td>
                            <input type="number" class="form-control jumlah" name="jumlah[]" min="1" value="1" required>
                        </td>
                        <td>
                            <input type="text" class="form-control subtotal" readonly value="0">
                        </td>
                        <td>
                            <button type="button" class="btn btn-danger btn-sm remove-row">X</button>
                        </td>
                    </tr>
                </tbody>
            </table>

            <button type="button" class="btn btn-success mb-3" id="addRow">Tambah Barang</button>

            <div class="mb-3">
                <label>Total Harga</label>
                <input type="text" name="total" class="form-control" id="totalHarga" readonly value="0">
            </div>

            <div class="mb-3">
                <label>Uang Bayar</label>
                <input type="number" name="bayar" class="form-control" id="uangBayar" placeholder="Masukkan jumlah uang bayar" required>
            </div>

            <div class="mb-3">
                <label>Kembalian</label>
                <input type="text" class="form-control" id="kembalian" readonly value="0">
            </div>

            <div class="d-grid mt-4">
                <button class="btn btn-primary" type="submit">Simpan & Cetak Nota</button>
            </div>
        </form>
    </div>
</div>
<!-- ================= END CONTENT ================= -->

<script>
document.addEventListener("DOMContentLoaded", function(){

    function updateSubtotal(row){
        const harga = parseInt(row.querySelector('.harga').value) || 0;
        const jumlah = parseInt(row.querySelector('.jumlah').value) || 0;
        row.querySelector('.subtotal').value = harga * jumlah;
    }

    function updateTotal(){
        let total = 0;
        document.querySelectorAll('.subtotal').forEach(s => {
            total += parseInt(s.value) || 0;
        });
        document.getElementById('totalHarga').value = total;

        const bayar = parseInt(document.getElementById('uangBayar').value) || 0;
        document.getElementById('kembalian').value = bayar - total;
    }

    document.getElementById('barangBody').addEventListener('change', function(e){
        if(e.target.classList.contains('barang-select')){
            const row = e.target.closest('tr');
            const harga = e.target.selectedOptions[0].dataset.harga || 0;
            row.querySelector('.harga').value = harga;
            updateSubtotal(row);
            updateTotal();
        }
    });

    document.getElementById('barangBody').addEventListener('input', function(e){
        if(e.target.classList.contains('jumlah') || e.target.id == 'uangBayar'){
            const row = e.target.closest('tr');
            if(e.target.classList.contains('jumlah')) updateSubtotal(row);
            updateTotal();
        }
    });

    document.getElementById('uangBayar').addEventListener('input', updateTotal);

    document.getElementById('addRow').addEventListener('click', function(){
        const tbody = document.getElementById('barangBody');
        const newRow = tbody.rows[0].cloneNode(true);
        newRow.querySelectorAll('input').forEach(input => input.value = input.classList.contains('jumlah') ? 1 : 0);
        newRow.querySelector('select').selectedIndex = 0;
        tbody.appendChild(newRow);
    });

    document.getElementById('barangBody').addEventListener('click', function(e){
        if(e.target.classList.contains('remove-row')){
            const tbody = document.getElementById('barangBody');
            if(tbody.rows.length > 1){
                e.target.closest('tr').remove();
                updateTotal();
            }
        }
    });

});
</script>

</body>
</html>
