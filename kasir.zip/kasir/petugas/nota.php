<?php
require_once "../main/connect.php";

$id = $_GET['id'];

// Ambil data penjualan
$penjualan = mysqli_fetch_assoc(mysqli_query($conn,
    "SELECT * FROM penjualan WHERE PenjualanID='$id'"
));

// Ambil detail barang (jika ada)
$detail = mysqli_query($conn,"
    SELECT d.*, b.NamaBarang
    FROM detail_penjualan d
    JOIN barang b ON b.BarangID = d.BarangID
    WHERE d.PenjualanID='$id'
");
?>

<!DOCTYPE html>
<html>
<head>
<title>Nota</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

<style>
body{
    background:white;
    font-family: monospace;
}
.nota{
    max-width:380px;
    margin:auto;
}
.table td, .table th{
    padding:4px;
    font-size:13px;
}
hr{
    border-top:1px dashed black;
}
</style>

</head>

<body onload="window.print()">

<div class="nota mt-3">

    <div class="text-center">
        <h5>FASHIONSHOP</h5>
        <small>Jl. Fashion No. 123</small><br>
        <small>Telp: 0812-3456-7890</small>
    </div>

    <hr>

    <p style="font-size:13px;">
        Tanggal : <?= $penjualan['Tanggal'] ?><br>
        Pelanggan : <?= htmlspecialchars($penjualan['NamaPelanggan']) ?>
    </p>

    <hr>

    <?php while($d = mysqli_fetch_assoc($detail)) { ?>
        <div style="font-size:13px;">
            <?= $d['NamaBarang'] ?><br>
            <?= $d['Jumlah'] ?> x <?= number_format($d['Harga'],0,',','.') ?>
            <span class="float-end">
                <?= number_format($d['Subtotal'],0,',','.') ?>
            </span>
        </div>
        <br>
    <?php } ?>

    <hr>

    <div style="font-size:14px;">
        <div>
            Total
            <span class="float-end">
                Rp <?= number_format($penjualan['TotalHarga'],0,',','.') ?>
            </span>
        </div>
        <div>
            Bayar
            <span class="float-end">
                Rp <?= number_format($penjualan['UangBayar'],0,',','.') ?>
            </span>
        </div>
        <div>
            Kembali
            <span class="float-end">
                Rp <?= number_format($penjualan['UangBayar'] - $penjualan['TotalHarga'],0,',','.') ?>
            </span>
        </div>
    </div>

    <hr>

    <div class="text-center mt-3" style="font-size:12px;">
        Terima kasih telah berbelanja 🙏<br>
        Barang yang sudah dibeli tidak dapat dikembalikan
    </div>

</div>

</body>
</html>
