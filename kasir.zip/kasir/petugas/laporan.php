<?php
require_once __DIR__ . "/../main/auth.php";
cekRole('petugas');
require_once __DIR__ . "/../main/connect.php";

$nama = $_SESSION['username'] ?? 'Petugas';

// ambil rekap barang terjual
$laporan = mysqli_query($conn,"
    SELECT 
        b.NamaBarang,
        SUM(d.Jumlah) as total_terjual,
        SUM(d.Subtotal) as total_uang
    FROM detail_penjualan d
    JOIN barang b ON d.BarangID = b.BarangID
    GROUP BY d.BarangID
    ORDER BY total_terjual DESC
");
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Laporan Penjualan</title>
<meta name="viewport" content="width=device-width, initial-scale=1">

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">

<style>
body{
    background:#f4f6f9;
    font-family: 'Segoe UI', sans-serif;
}

/* SIDEBAR */
.sidebar{
    width:260px;
    min-height:100vh;
    background:linear-gradient(180deg,#0f172a,#0b1a33);
    color:white;
    position:fixed;
}

.sidebar .nav-link{
    color:#cbd5e1;
    padding:12px 18px;
    border-radius:12px;
    margin-bottom:5px;
}

.sidebar .nav-link:hover,
.sidebar .nav-link.active{
    background:#2563eb;
    color:white;
}

/* CONTENT */
.content{
    margin-left:260px;
    padding:30px;
}

/* PRINT */
@media print {
    .sidebar, .btn-print {
        display:none;
    }
    .content{
        margin-left:0;
        padding:10px;
    }
}
</style>
</head>

<body>

<!-- ================= SIDEBAR ================= -->
<div class="sidebar p-3">
    <h4 class="mb-1"><i class="bi bi-shop"></i> Modefyshop</h4>
    <small class="text-secondary">PETUGAS</small>

    <hr class="border-secondary">

    <ul class="nav flex-column">
        <li class="nav-item">
            <a class="nav-link" href="index.php">
                <i class="bi bi-speedometer2"></i> Dashboard
            </a>
        </li>

        <li class="nav-item">
            <a class="nav-link" href="penjualan.php">
                <i class="bi bi-cart"></i> Penjualan
            </a>
        </li>

        <li class="nav-item">
            <a class="nav-link" href="produck.php">
                <i class="bi bi-box"></i> Data Produck
            </a>
        </li>

        <li class="nav-item">
            <a class="nav-link" href="pelanggan.php">
                <i class="bi bi-people"></i> Data Pelanggan
            </a>
        </li>

        <!-- ACTIVE -->
        <li class="nav-item">
            <a class="nav-link active" href="laporan.php">
                <i class="bi bi-graph-up"></i> Laporan
            </a>
        </li>

        <hr class="border-secondary">

        <li class="nav-item">
            <a class="nav-link text-danger" href="../auth/logout.php">
                <i class="bi bi-box-arrow-left"></i> Keluar
            </a>
        </li>
    </ul>
</div>
<!-- ================= END SIDEBAR ================= -->


<!-- ================= CONTENT ================= -->
<div class="content">

    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2 class="text-primary">
            <i class="bi bi-graph-up"></i> Laporan Barang Terjual
        </h2>

        <button onclick="window.print()" class="btn btn-success btn-print">
            <i class="bi bi-printer"></i> Print
        </button>
    </div>

    <div class="card shadow">
        <div class="card-body">

            <table class="table table-bordered table-hover">
                <thead class="table-primary">
                    <tr>
                        <th width="60">No</th>
                        <th>Nama Barang</th>
                        <th>Total Terjual</th>
                        <th>Total Uang</th>
                    </tr>
                </thead>
                <tbody>

                <?php 
                $no = 1;
                while($r = mysqli_fetch_assoc($laporan)) { 
                ?>
                    <tr>
                        <td><?= $no++ ?></td>
                        <td><?= $r['NamaBarang'] ?></td>
                        <td><?= $r['total_terjual'] ?></td>
                        <td>
                            Rp <?= number_format($r['total_uang'],0,',','.') ?>
                        </td>
                    </tr>
                <?php } ?>

                </tbody>
            </table>

        </div>
    </div>

</div>


</body>
</html>
