<div class="col-10 p-4">
    <!-- ISI HALAMAN -->
</div>

</div>
</div>

</body>
</html>
