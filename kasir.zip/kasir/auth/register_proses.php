<?php
session_start();
require_once '../main/connect.php';

// Pastikan file dipanggil via POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: register.php');
    exit;
}

// Ambil dan bersihkan data
$Username = trim($_POST['username'] ?? '');
$Password = $_POST['password'] ?? '';
$Role     = strtolower(trim($_POST['role'] ?? ''));

// Validasi input
if (!$Username || !$Password || !$Role) {
    die("Form belum lengkap, semua field harus diisi.");
}

// Hanya boleh admin atau costumer (sesuai database)
$allowed_roles = ['admin', 'costumer'];
if (!in_array($Role, $allowed_roles)) {
    die("Role hanya boleh admin atau costumer.");
}

// Hash password
$hashed_password = password_hash($Password, PASSWORD_DEFAULT);

// Cek username sudah ada
$stmt = $conn->prepare("SELECT UserID FROM user WHERE Username = ?");
$stmt->bind_param("s", $Username);
$stmt->execute();
$stmt->store_result();

if ($stmt->num_rows > 0) {
    $stmt->close();
    $conn->close();
    die("Username sudah digunakan!");
}
$stmt->close();

// Simpan data user baru
$stmt = $conn->prepare("INSERT INTO user (Username, Password, Role) VALUES (?, ?, ?)");
$stmt->bind_param("sss", $Username, $hashed_password, $Role);

if ($stmt->execute()) {
    // Registrasi sukses → redirect ke login
    header("Location: login.php");
    exit;
} else {
    die("Terjadi kesalahan saat menyimpan data: " . $stmt->error);
}

$stmt->close();
$conn->close();
