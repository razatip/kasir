<?php
session_start();
require_once __DIR__ . "/../main/connect.php";

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: login.php");
    exit;
}

// Ambil data dari form
$Username = trim($_POST['username'] ?? '');
$Password = $_POST['password'] ?? '';

if (!$Username || !$Password) {
    echo "<script>alert('Username dan password harus diisi'); window.location='login.php';</script>";
    exit;
}

// ==== PETUGAS MANUAL ====
$manual_petugas = [
    'petugas1' => '12345', 
    'petugas2' => 'pass123'
];

if (isset($manual_petugas[$Username]) && $Password === $manual_petugas[$Username]) {
    $_SESSION['login'] = true;
    $_SESSION['id_user'] = 0; // karena tidak dari DB
    $_SESSION['role'] = 'petugas';
    header("Location: ../admin/index.php");
    exit;
}

// ==== CEK DATABASE ====
$stmt = $conn->prepare("SELECT UserID, Password, Role FROM user WHERE Username = ?");
$stmt->bind_param("s", $Username);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();
$stmt->close();

if ($user && password_verify($Password, $user['Password'])) {
    $_SESSION['login'] = true;
    $_SESSION['id_user'] = $user['UserID'];
    
    // Bersihkan role
    $role = strtolower(trim($user['Role']));
    $_SESSION['role'] = $role;

    // Redirect sesuai role
    if ($role === 'admin') {
        header("Location: ../admin/index.php");
        exit;
    } elseif ($role === 'costumer') {
        header("Location: ../user/index.php");
        exit;
    } else {
        session_destroy();
        echo "<script>alert('Role user tidak valid. Hubungi admin.'); window.location='login.php';</script>";
        exit;
    }
} else {
    echo "<script>alert('Login gagal! Username atau password salah.'); window.location='login.php';</script>";
    exit;
}

$conn->close();
