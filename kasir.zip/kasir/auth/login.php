<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Login | Fashionshop</title>

    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@600;700&family=Poppins:wght@300;400;500&display=swap" rel="stylesheet">

    <style>
        body {
            min-height: 100vh;
            background:
                linear-gradient(135deg, rgba(0,0,0,.25), rgba(0,0,0,.35)),
               url("../assets/img/bg.jpg");
            background-size: cover;
            background-position: center;
            display: flex;
            align-items: center;
            justify-content: center;
            font-family: 'Poppins', sans-serif;
        }

        .login-card {
            width: 380px;
            padding: 36px 30px;
            border-radius: 22px;

            /* GLASS EFFECT */
            background: rgba(255, 255, 255, 0.15);
            backdrop-filter: blur(14px);
            -webkit-backdrop-filter: blur(14px);

            border: 1px solid rgba(255, 255, 255, 0.25);
            box-shadow: 0 20px 40px rgba(0,0,0,.25);

            animation: fadeIn .7s ease;
        }

        .brand-title {
            font-family: 'Playfair Display', serif;
            font-weight: 700;
            letter-spacing: 1px;
            color: #ffffff;
        }

        .brand-sub {
            font-size: 0.85rem;
            color: #e5e7eb;
        }

        .fashion-line {
            width: 48px;
            height: 2px;
            background: #e5e7eb;
            margin: 12px auto;
            border-radius: 4px;
        }

        .form-label {
            font-size: 0.75rem;
            letter-spacing: .5px;
            color: #e5e7eb;
        }

        .form-control {
            background: rgba(255,255,255,0.15);
            border: 1px solid rgba(255,255,255,0.3);
            color: #fff;
            border-radius: 14px;
            padding: 12px 14px;
        }

        .form-control::placeholder {
            color: #e5e7eb;
            opacity: .7;
        }

        .form-control:focus {
            background: rgba(255,255,255,0.25);
            border-color: #fff;
            box-shadow: none;
            color: #fff;
        }

        .input-group-text {
            background: rgba(255,255,255,0.2);
            border: 1px solid rgba(255,255,255,0.3);
            color: #fff;
            border-radius: 14px 0 0 14px;
        }

        .btn-login {
            background: #ffffff;
            color: #111827;
            border-radius: 16px;
            padding: 11px;
            font-weight: 500;
            letter-spacing: .5px;
            border: none;
        }

        .btn-login:hover {
            background: #f3f4f6;
        }

        .btn-register {
            border-radius: 16px;
            font-size: 0.85rem;
            color: #fff;
            border-color: rgba(255,255,255,0.4);
        }

        .btn-register:hover {
            background: rgba(255,255,255,0.15);
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(12px); }
            to { opacity: 1; transform: translateY(0); }
        }
    </style>
</head>

<body>

<div class="login-card">
    <div class="text-center mb-4">
        <h3 class="brand-title">FASHIONSHOP</h3>
        <div class="fashion-line"></div>
        <p class="brand-sub">Luxury Style Access</p>
    </div>

    <form action="login_proses.php" method="POST">

        <div class="mb-3">
            <label class="form-label">USERNAME</label>
            <div class="input-group">
                <span class="input-group-text">
                    <i class="bi bi-person"></i>
                </span>
                <input type="text" name="username" class="form-control" placeholder="your username" required>
            </div>
        </div>

        <div class="mb-4">
            <label class="form-label">PASSWORD</label>
            <div class="input-group">
                <span class="input-group-text">
                    <i class="bi bi-lock"></i>
                </span>
                <input type="password" name="password" class="form-control" placeholder="••••••••" required>
            </div>
        </div>

        <button type="submit" class="btn btn-login w-100 mb-3">
            SIGN IN
        </button>

        <a href="register.php" class="btn btn-outline-light w-100 btn-register">
            CREATE ACCOUNT
        </a>

    </form>

    <div class="text-center mt-4">
        <small class="text-light opacity-75">© 2026 Fashionshop</small>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
