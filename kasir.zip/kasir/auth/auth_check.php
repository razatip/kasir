<?php
session_start();

function cekRole($role) {
    if (!isset($_SESSION['login'])) {
        // Belum login
        header("Location: login.php");
        exit;
    }

    if ($_SESSION['role'] != $role) {
        // Role tidak sesuai
        if ($_SESSION['role'] == 'admin') {
            header("Location: ../admin/index.php");
        } else {
            header("Location: ../petugas/index.php");
        }
        exit;
    }
}
